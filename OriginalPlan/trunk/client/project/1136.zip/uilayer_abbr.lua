return {
cName="n", picName="p", audio="a", data="d", 
width="w", height="h", scaleX="sx", scaleY="sy", 
scrollAlign="sa", scrollMargin="sm",
tag="t", isEnlarge="e", isSTensile="st", type="tp", frameType="ft", 
textType="tt", text="tx", useRTF="r", textShade="ts", fontSize="s", fontColor="c", align="an", 
progressBar="pb", button="b",
}