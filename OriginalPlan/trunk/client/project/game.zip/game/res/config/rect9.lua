local data = {}
data.rect9 = {
	["#fight_dk001.png"] = {100,5,10,5}
	,["#fightFog.png"]={1,1,5,5}
	,["#chat_bg_1.png"]={26,45,30,5}
	,["#friend_xdb3.png"]={70,35,90,5}
	,["#arena_xdi_3.png"]={130,50,10,20}   --arena_xdi_2.png 796 121
	,["#arena_xxdi.png"]={30,25,5,5}  --468,70
    ,["#mail_yjd.png"]={140,0,100,121}
    ,['#hud_wzd1.png'] = {19,16,62,9}
    ,["#com_xd1.png"]={30,10,62,8}--122 28
	,["#com_fgx.png"]={186,0,200,6}
	,["#arena_xxdik.png"]={40,30,5,5}  --791 81
	,['#compete_zidi.png'] = {37,62,104,25}
	,["#hdtb_bg1.png"] = {45,30,5,2} --443 89
    ,["#guild_db3.png"]={70,70,5,5}
    ,["#tl_db2.png"]={40,40,5,5} --419 188
	,["#leader_db6c.png"]={45,40,5,5}--260 281
	,["#xtts_diban.png"]={70,50,5,5}
	,['#com_ditu2.png']={100,0,100,520}--232 520
    ,['#com_zjmd_3.png']={40,25,2,2} --468 70
	,["#fight_sxp.png"]={70,1,5,10}
	,["#friend_srk.png"]={55,22,2,2} -- 424 50
	,["#com_tips.png"]={70,30,5,1}
	,["#com_db3.png"]={220,150,10,10}
	,["#com_di_all.png"]={230,100,2,2}
	,["#com_dp5.png"]={230,100,2,2} --857 598
	,["#mtips_bg_1.png"]={55,10,2,2}
    ,["#yw_bg_1.png"]={55,10,2,2}
    ,["#yw_bg_2.png"]={20,10,25,20}
	,["#leader_db6.png"] = {174,22,40,20}
    ,['#com_zjmd_1.png']={40,25,2,2} --570 316
	,["#yw_bg_4.png"] = {48,30,2,2}
	,["#fight_bg_6.png"] = {48,30,2,2}
	,["#dw_btn_2.png"] = {65, 30, 2, 2}
	,["#dw_btn_2.png"] = {70, 30, 2, 2}
}

data.defaultSize = {
}

return data