do return{

CFixNullBase = {
  type = "class",
},
CFixLenBase = {
  type = "class",
},
IStreamable = {
  type = "class",
},
IUnStreamable = {
  type = "class",
},
IStreamableAll = {
  type = "class",
},
IStream = {
  type = "class",
},
IUnStream = {
  type = "class",
},
ILockable = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "ILockable",
      valuetype = "ILockable",
    },
    leave={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    enter={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CEmptyLock = {
  type = "class",
  inherits = "ILockable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CEmptyLock",
      valuetype = "CEmptyLock",
    },
    leave={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    enter={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CUnfairMutex = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CUnfairMutex",
      valuetype = "CUnfairMutex",
    },
    leave={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    enter={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CFastLock = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CFastLock",
      valuetype = "CFastLock",
    },
  },
},
CFairMutex = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CFairMutex",
      valuetype = "CFairMutex",
    },
    leave={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    enter={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CTimeVal = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CTimeVal",
      valuetype = "CTimeVal",
    },
    toTimeVal={
      type = "method",
      returns = "timeval",
      valuetype = "timeval"
    },
  },
},
CTime = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CTime",
      valuetype = "CTime",
    },
  },
},
CTimespan = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CTimespan",
      valuetype = "CTimespan",
    },
    reset={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    totalHours={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    seconds={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    days={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    hours={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    totalMinutes={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getTimeSpan={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    totalSeconds={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    minutes={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
  },
},
CDateTime = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CDateTime",
      valuetype = "CDateTime",
    },
    week={
      type = "method",
      args = "int: firstDayOfWeek,",
      returns = "int",
      valuetype = "int"
    },
    dayOfWeek={
      type = "method",
      returns = "EDaysOfWeek",
      valuetype = "EDaysOfWeek"
    },
    isAM={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    totalMins={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    totalDays={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    hour={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    isPM={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    totalSecs={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    minute={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    update={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    month={
      type = "method",
      returns = "EMonths",
      valuetype = "EMonths"
    },
    totalHours={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    hourAMPM={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    second={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    dayOfYear={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    year={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    utcTime={
      type = "method",
      returns = "long long",
      valuetype = "long long"
    },
    day={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
  },
},
CTimeManager = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CTimeManager",
      valuetype = "CTimeManager",
    },
    getWeek={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getHour={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getYear={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getMonth={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    time2Number={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    nowSysTime={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    getSecond={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    update={
      type = "method",
      returns = "long long",
      valuetype = "long long"
    },
    getDay={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    runTime={
      type = "method",
      returns = "long long",
      valuetype = "long long"
    },
    getMinute={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    localTime={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    nowAppTime={
      type = "method",
      returns = "long long",
      valuetype = "long long"
    },
    getANSITime={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    startAppTime={
      type = "method",
      returns = "long long",
      valuetype = "long long"
    },
    getTodayTime={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    getLocalWeek={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getLocalMonth={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getDayTime={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    currentDate={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},
CGxContext = {
  type = "class",
  inherits = "CManualSingleton<GXMISC::CGxContext> ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CGxContext",
      valuetype = "CGxContext",
    },
    getMainThread={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    getStopSigno={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    getStopHandler={
      type = "method",
      returns = "IStopHandler",
      valuetype = "IStopHandler"
    },
    callOnCrash={
      type = "method",
      args = "string: dumpName,",
      returns = "void",
      valuetype = "void"
    },
    clear={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    getMainLog={
      type = "method",
      returns = "CLogger",
      valuetype = "CLogger"
    },
    update={
      type = "method",
      args = "unsigned int: diff,",
      returns = "void",
      valuetype = "void"
    },
    getFastLogThread={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    init={
      type = "method",
      args = "string: serverName,",
      returns = "bool",
      valuetype = "bool"
    },
    setFastLogThread={
      type = "method",
      args = "unsigned long long: threadID,",
      returns = "void",
      valuetype = "void"
    },
    setServerName={
      type = "method",
      args = "string: serverName,",
      returns = "void",
      valuetype = "void"
    },
    getServerName={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    setStopSigno={
      type = "method",
      args = "unsigned int: sig,",
      returns = "void",
      valuetype = "void"
    },
    setDumpHandler={
      type = "method",
      args = "IDumpHandler: dumpHandler,",
      returns = "void",
      valuetype = "void"
    },
    setStopHandler={
      type = "method",
      args = "IStopHandler: stopHandler,",
      returns = "void",
      valuetype = "void"
    },
    exitCallback={
      type = "method",
      args = "EExitCode: code,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CLogger = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CLogger",
      valuetype = "CLogger",
    },
    addNegativeFilter={
      type = "method",
      args = "char: filterstr,",
      returns = "void",
      valuetype = "void"
    },
    displayFilter={
      type = "method",
      args = "CLogger: log,",
      returns = "void",
      valuetype = "void"
    },
    resetFilters={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    flush={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    attached={
      type = "method",
      args = "IDisplayer: displayer,",
      returns = "bool",
      valuetype = "bool"
    },
    update={
      type = "method",
      args = "unsigned int: diff,",
      returns = "void",
      valuetype = "void"
    },
    removeFilter={
      type = "method",
      args = "char: filterstr,",
      returns = "void",
      valuetype = "void"
    },
    addPositiveFilter={
      type = "method",
      args = "char: filterstr,",
      returns = "void",
      valuetype = "void"
    },
    synLog={
      type = "method",
      args = "string: str,",
      returns = "void",
      valuetype = "void"
    },
    calcLogNum={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    setPosition={
      type = "method",
      args = "ELogType: logType,",
      args = "bool: unrepeat,",
      args = "int: line,",
      args = "char: fileName,",
      args = "char: funcName,",
      args = "char: module,",
      args = "bool: isSync,",
      returns = "void",
      valuetype = "void"
    },
    getDisplayer={
      type = "method",
      args = "char: displayerName,",
      returns = "IDisplayer",
      valuetype = "IDisplayer"
    },
    addDisplayer={
      type = "method",
      args = "IDisplayer: displayer,",
      args = "bool: bypassFilter,",
      returns = "void",
      valuetype = "void"
    },
    noDisplayer={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
  },
},
CSafeLog = {
  type = "class",
  inherits = "CLogger ",
},
IDisplayer = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "IDisplayer",
      valuetype = "IDisplayer",
    },
    leave={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    isNeedDeleteByLog={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getName={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    enter={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CStdDisplayer = {
  type = "class",
  inherits = "IDisplayer ",
},
CSafeStdDisplayer = {
  type = "class",
  inherits = "CStdDisplayer ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CSafeStdDisplayer",
      valuetype = "CSafeStdDisplayer",
    },
    leave={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    enter={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CFileDisplayer = {
  type = "class",
  inherits = "IDisplayer ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CFileDisplayer",
      valuetype = "CFileDisplayer",
    },
    setParam={
      type = "method",
      args = "string: displayerName,",
      args = "unsigned int: size,",
      args = "bool: eraseLastLog,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CSafeFileDispalyer = {
  type = "class",
  inherits = "CFileDisplayer ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CSafeFileDispalyer",
      valuetype = "CSafeFileDispalyer",
    },
    leave={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    enter={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CBit8 = {
  type = "class",
  inherits = "CFixBitSet<8> ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CBit8",
      valuetype = "CBit8",
    },
    toUInt8={
      type = "method",
      returns = "unsigned char",
      valuetype = "unsigned char"
    },
  },
},
CBit16 = {
  type = "class",
  inherits = "CFixBitSet<16> ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CBit16",
      valuetype = "CBit16",
    },
    toUInt16={
      type = "method",
      returns = "unsigned short",
      valuetype = "unsigned short"
    },
  },
},
CBit32 = {
  type = "class",
  inherits = "CFixBitSet<32> ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CBit32",
      valuetype = "CBit32",
    },
    toUInt32={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},
CBit64 = {
  type = "class",
  inherits = "CFixBitSet<64> ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CBit64",
      valuetype = "CBit64",
    },
    toUInt64={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
  },
},
CCPUTimeStat = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CCPUTimeStat",
      valuetype = "CCPUTimeStat",
    },
    getProcessSystemLoad={
      type = "method",
      args = "TMeasureType: type,",
      returns = "float",
      valuetype = "float"
    },
    getProcessCSystemLoad={
      type = "method",
      args = "TMeasureType: type,",
      returns = "float",
      valuetype = "float"
    },
    getCPUNiceLoad={
      type = "method",
      args = "TMeasureType: type,",
      returns = "float",
      valuetype = "float"
    },
    getProcessCUserLoad={
      type = "method",
      args = "TMeasureType: type,",
      returns = "float",
      valuetype = "float"
    },
    getCPUIOWaitLoad={
      type = "method",
      args = "TMeasureType: type,",
      returns = "float",
      valuetype = "float"
    },
    getCPUUserLoad={
      type = "method",
      args = "TMeasureType: type,",
      returns = "float",
      valuetype = "float"
    },
    getProcessCLoad={
      type = "method",
      args = "TMeasureType: type,",
      returns = "float",
      valuetype = "float"
    },
    getProcessLoad={
      type = "method",
      args = "TMeasureType: type,",
      returns = "float",
      valuetype = "float"
    },
    peekMeasures={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    getCPUSystemLoad={
      type = "method",
      args = "TMeasureType: type,",
      returns = "float",
      valuetype = "float"
    },
    getCPULoad={
      type = "method",
      args = "TMeasureType: type,",
      returns = "float",
      valuetype = "float"
    },
    getProcessUserLoad={
      type = "method",
      args = "TMeasureType: type,",
      returns = "float",
      valuetype = "float"
    },
  },
},
CSimpleAllocator = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CSimpleAllocator",
      valuetype = "CSimpleAllocator",
    },
    alloc={
      type = "method",
      args = "int: n,",
      returns = "char",
      valuetype = "char"
    },
    getTotalAllocSize={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    setThreadID={
      type = "method",
      args = "unsigned long long: tid,",
      returns = "void",
      valuetype = "void"
    },
    free={
      type = "method",
      args = "char: p,",
      returns = "void",
      valuetype = "void"
    },
  },
},
IStopHandler = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "IStopHandler",
      valuetype = "IStopHandler",
    },
    setStop={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setStart={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    onStop={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    isStop={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
  },
},
IRunnable = {
  type = "class",
  inherits = "IStopHandler ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "IRunnable",
      valuetype = "IRunnable",
    },
    run={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setName={
      type = "method",
      args = "string: name,",
      returns = "void",
      valuetype = "void"
    },
    getThreadID={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    getName={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setThreadID={
      type = "method",
      args = "unsigned long long: tid,",
      returns = "void",
      valuetype = "void"
    },
    isExitRun={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    setExitRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
IAllocatable = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "IAllocatable",
      valuetype = "IAllocatable",
    },
    allocArg={
      type = "method",
      args = "unsigned int: size,",
      returns = "char",
      valuetype = "char"
    },
    freeArg={
      type = "method",
      args = "char: arg,",
      returns = "void",
      valuetype = "void"
    },
  },
},
ISyncable = {
  type = "class",
  inherits = "IRunnable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "ISyncable",
      valuetype = "ISyncable",
    },
    setUsed={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    doAfterUsed={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    doAfterFromQueue={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setFreed={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    doBeforeToQueueue={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    canFree={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
  },
},
IFreeable = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "IFreeable",
      valuetype = "IFreeable",
    },
    isNeedFree={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    setNeedFree={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
IDumpHandler = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "IDumpHandler",
      valuetype = "IDumpHandler",
    },
    onDump={
      type = "method",
      args = "string: dumpName,",
      returns = "void",
      valuetype = "void"
    },
  },
},
ISimpleNoncopyable = {
  type = "class",
},
INoncopyable = {
  type = "class",
},
CDebugControl = {
  type = "class",
  inherits = "CManualSingleton<GXMISC::CDebugControl> ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CDebugControl",
      valuetype = "CDebugControl",
    },
    setTaskVar={
      type = "method",
      args = "bool: val,",
      returns = "void",
      valuetype = "void"
    },
    getDatabaseProfileVar={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    setDatabaseProfileVar={
      type = "method",
      args = "bool: val,",
      returns = "void",
      valuetype = "void"
    },
    getServiceStopVar={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getTaskBlockAllocVar={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    setServiceStopVar={
      type = "method",
      args = "bool: val,",
      returns = "void",
      valuetype = "void"
    },
    setTaskProfileVar={
      type = "method",
      args = "bool: val,",
      returns = "void",
      valuetype = "void"
    },
    getTaskProfileVar={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    setMainLoopProfileVar={
      type = "method",
      args = "bool: val,",
      returns = "void",
      valuetype = "void"
    },
    setTaskBlockAllocVar={
      type = "method",
      args = "bool: val,",
      returns = "void",
      valuetype = "void"
    },
    addHandler={
      type = "method",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
    setSocketProfileVar={
      type = "method",
      args = "bool: val,",
      returns = "void",
      valuetype = "void"
    },
    getSocketLoopProfileVar={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getSocketProfileVar={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    setSocketLoopProfileVar={
      type = "method",
      args = "bool: val,",
      returns = "void",
      valuetype = "void"
    },
    isHandler={
      type = "method",
      args = "unsigned long long: index,",
      returns = "bool",
      valuetype = "bool"
    },
    getMainLoopProfileVar={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getSocketBufferVar={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getTaskVar={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    setSocketBufferVar={
      type = "method",
      args = "bool: val,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CTask = {
  type = "class",
  inherits = "ISyncable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CTask",
      valuetype = "CTask",
    },
    doAfterUsed={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setTaskQueueWrap={
      type = "method",
      args = "CSyncActiveQueueWrap: wrap,",
      returns = "void",
      valuetype = "void"
    },
    doRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    getLoopThread={
      type = "method",
      returns = "CModuleThreadLoop",
      valuetype = "CModuleThreadLoop"
    },
    getArgNum={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    setPriority={
      type = "method",
      args = "unsigned char: prority,",
      returns = "void",
      valuetype = "void"
    },
    setObjUID={
      type = "method",
      args = "unsigned long long: uid,",
      returns = "void",
      valuetype = "void"
    },
    getArgLen={
      type = "method",
      args = "unsigned int: index,",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    getStartTime={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    allocArg={
      type = "method",
      args = "unsigned int: size,",
      returns = "char",
      valuetype = "char"
    },
    getName={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    setLoopThreadWrap={
      type = "method",
      args = "CModuleThreadLoopWrap: loopThreadWrap,",
      returns = "void",
      valuetype = "void"
    },
    addArg={
      type = "method",
      args = "char: arg,",
      args = "unsigned int: argLen,",
      returns = "void",
      valuetype = "void"
    },
    getPriority={
      type = "method",
      returns = "unsigned char",
      valuetype = "unsigned char"
    },
    getTotalArgLen={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    type={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    run={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    getLoopThreadWrap={
      type = "method",
      returns = "CModuleThreadLoopWrap",
      valuetype = "CModuleThreadLoopWrap"
    },
    getObjUID={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    setAllocable={
      type = "method",
      args = "IAllocatable: allocator,",
      returns = "void",
      valuetype = "void"
    },
    setLoopThread={
      type = "method",
      args = "CModuleThreadLoop: loopThread,",
      returns = "void",
      valuetype = "void"
    },
    freeArg={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    pushToQueue={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CSyncActiveQueue = {
  type = "class",
  inherits = "IAllocatable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CSyncActiveQueue",
      valuetype = "CSyncActiveQueue",
    },
    setReadThreadID={
      type = "method",
      args = "unsigned long long: tid,",
      returns = "void",
      valuetype = "void"
    },
    calcWriteMsgNum={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    updateProfileData={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setProfileFlag={
      type = "method",
      args = "bool: flag,",
      returns = "void",
      valuetype = "void"
    },
    getTaskNum={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    flushWriteMsg={
      type = "method",
      args = "bool: flag,",
      returns = "void",
      valuetype = "void"
    },
    updateRead={
      type = "method",
      args = "unsigned int: diff,",
      returns = "void",
      valuetype = "void"
    },
    updateWrite={
      type = "method",
      args = "unsigned int: diff,",
      args = "bool: isAll,",
      returns = "void",
      valuetype = "void"
    },
    flushReadMsg={
      type = "method",
      args = "bool: flag,",
      returns = "void",
      valuetype = "void"
    },
    setWriteThreadID={
      type = "method",
      args = "unsigned long long: tid,",
      returns = "void",
      valuetype = "void"
    },
    setQueueName={
      type = "method",
      args = "string: queueName,",
      returns = "void",
      valuetype = "void"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    calcReadMsgNum={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    doProfile={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    cleanReadMsg={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CSyncActiveQueueWrap = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CSyncActiveQueueWrap",
      valuetype = "CSyncActiveQueueWrap",
    },
    flushQueue={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setLoopThread={
      type = "method",
      args = "CModuleThreadLoop: loopThread,",
      returns = "void",
      valuetype = "void"
    },
    setLoopThreadWrap={
      type = "method",
      args = "CModuleThreadLoopWrap: loopThreadWrap,",
      returns = "void",
      valuetype = "void"
    },
    setCommunicationQ={
      type = "method",
      args = "CSyncActiveQueue: inputQ,",
      args = "CSyncActiveQueue: outputQ,",
      returns = "void",
      valuetype = "void"
    },
    update={
      type = "method",
      args = "unsigned int: diff,",
      returns = "void",
      valuetype = "void"
    },
    genUID={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    handleTask={
      type = "method",
      args = "int: diff,",
      returns = "void",
      valuetype = "void"
    },
    setThreadID={
      type = "method",
      args = "unsigned long long: tid,",
      returns = "void",
      valuetype = "void"
    },
    freeObj={
      type = "method",
      args = "CTask: task,",
      returns = "void",
      valuetype = "void"
    },
    doProfile={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CIntervalTimer = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CIntervalTimer",
      valuetype = "CIntervalTimer",
    },
    reset={
      type = "method",
      args = "bool: force,",
      returns = "void",
      valuetype = "void"
    },
    getCurInterval={
      type = "method",
      returns = "long long",
      valuetype = "long long"
    },
    getRemainInterval={
      type = "method",
      returns = "long long",
      valuetype = "long long"
    },
    isValid={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    setMaxNum={
      type = "method",
      args = "unsigned int: num,",
      returns = "void",
      valuetype = "void"
    },
    update={
      type = "method",
      args = "long long: diff,",
      returns = "void",
      valuetype = "void"
    },
    isPassed={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      args = "unsigned int: maxInterval,",
      args = "unsigned int: num,",
      returns = "void",
      valuetype = "void"
    },
    onTimeout={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    doTimeout={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setMaxInterval={
      type = "method",
      args = "long long: maxInterval,",
      returns = "void",
      valuetype = "void"
    },
    getRemainSecs={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getMaxSecs={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
  },
},
CManualIntervalTimer = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CManualIntervalTimer",
      valuetype = "CManualIntervalTimer",
    },
    reset={
      type = "method",
      args = "bool: force,",
      returns = "void",
      valuetype = "void"
    },
    getCurInterval={
      type = "method",
      returns = "long long",
      valuetype = "long long"
    },
    getRemainInterval={
      type = "method",
      returns = "long long",
      valuetype = "long long"
    },
    update={
      type = "method",
      args = "long long: diff,",
      returns = "bool",
      valuetype = "bool"
    },
    isPassed={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      args = "unsigned int: maxInterval,",
      returns = "void",
      valuetype = "void"
    },
    setMaxInterval={
      type = "method",
      args = "long long: maxInterval,",
      returns = "void",
      valuetype = "void"
    },
    getRemainSecs={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getMaxSecs={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
  },
},
CIntervalTimerMgr = {
  type = "class",
  inherits = "CManualSingleton<GXMISC::CIntervalTimerMgr> ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CIntervalTimerMgr",
      valuetype = "CIntervalTimerMgr",
    },
    addTimer={
      type = "method",
      args = "CIntervalTimer: timer,",
      args = "bool: isNeedFree,",
      returns = "void",
      valuetype = "void"
    },
    update={
      type = "method",
      args = "long long: diff,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CConfigMap = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CConfigMap",
      valuetype = "CConfigMap",
    },
    readTypeIfExist={
      type = "method",
      args = "char: section,",
      args = "char: key,",
      args = "string: value,",
      returns = "bool",
      valuetype = "bool"
    },
    getConfigs={
      type = "method",
      returns = "map<basic_string<char>, map<basic_string<char>, basic_string<char>, less<basic_string<char> >, allocator<pair<const basic_string<char>, basic_string<char> > > >, less<basic_string<char> >, allocator<pair<const basic_string<char>, map<basic_string<char>, basic_string<char>, less<basic_string<char> >, allocator<pair<const basic_string<char>, basic_string<char> > > > > > >",
      valuetype = "map<basic_string<char>, map<basic_string<char>, basic_string<char>, less<basic_string<char> >, allocator<pair<const basic_string<char>, basic_string<char> > > >, less<basic_string<char> >, allocator<pair<const basic_string<char>, map<basic_string<char>, basic_string<char>, less<basic_string<char> >, allocator<pair<const basic_string<char>, basic_string<char> > > > > > >"
    },
    readConfigValue={
      type = "method",
      args = "char: section,",
      args = "char: key,",
      returns = "int",
      valuetype = "int"
    },
    setConfigs={
      type = "method",
      args = "map<basic_string<char>, map<basic_string<char>, basic_string<char>, less<basic_string<char> >, allocator<pair<const basic_string<char>, basic_string<char> > > >, less<basic_string<char> >, allocator<pair<const basic_string<char>, map<basic_string<char>, basic_string<char>, less<basic_string<char> >, allocator<pair<const basic_string<char>, basic_string<char> > > > > > >: configs,",
      returns = "void",
      valuetype = "void"
    },
    readConfigText={
      type = "method",
      args = "char: section,",
      args = "char: key,",
      returns = "string",
      valuetype = "string"
    },
  },
},
IModuleConfig = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "IModuleConfig",
      valuetype = "IModuleConfig",
    },
    getFrameNumPerSecond={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    setModuleName={
      type = "method",
      args = "string: name,",
      returns = "void",
      valuetype = "void"
    },
    getCloseWaitSecsAllLoop={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getMaxUserNumPerLoop={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getModuleName={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    onLoadConfig={
      type = "method",
      args = "CConfigMap: configs,",
      returns = "bool",
      valuetype = "bool"
    },
    getLoopThreadNum={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    check={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
  },
},
IModuleManager = {
  type = "class",
  inherits = "IStopHandler ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "IModuleManager",
      valuetype = "IModuleManager",
    },
    setModuleName={
      type = "method",
      args = "string: name,",
      returns = "void",
      valuetype = "void"
    },
    start={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getModuleName={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    getModuleConfig={
      type = "method",
      returns = "IModuleConfig",
      valuetype = "IModuleConfig"
    },
    onLoadConfig={
      type = "method",
      args = "CConfigMap: configs,",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    loop={
      type = "method",
      args = "int: diff,",
      returns = "bool",
      valuetype = "bool"
    },
    onStat={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
IServiceModule = {
  type = "class",
  inherits = "IModuleManager ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "IServiceModule",
      valuetype = "IServiceModule",
    },
    getCurrentLoopTime={
      type = "method",
      returns = "long long",
      valuetype = "long long"
    },
    start={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    isInitLoop={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getLastLoopTime={
      type = "method",
      returns = "long long",
      valuetype = "long long"
    },
    loop={
      type = "method",
      args = "int: diff,",
      returns = "bool",
      valuetype = "bool"
    },
  },
},
CModuleThreadLoop = {
  type = "class",
  inherits = "IRunnable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CModuleThreadLoop",
      valuetype = "CModuleThreadLoop",
    },
    getThreadLoopWrap={
      type = "method",
      returns = "CModuleThreadLoopWrap",
      valuetype = "CModuleThreadLoopWrap"
    },
    run={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setLoopWrap={
      type = "method",
      args = "CModuleThreadLoopWrap: loopWrap,",
      returns = "void",
      valuetype = "void"
    },
    freeTask={
      type = "method",
      args = "CTask: arg,",
      returns = "void",
      valuetype = "void"
    },
    setFreeFlag={
      type = "method",
      args = "bool: flag,",
      returns = "void",
      valuetype = "void"
    },
    setCommunicationQ={
      type = "method",
      args = "CSyncActiveQueue: inputQ,",
      args = "CSyncActiveQueue: outputQ,",
      returns = "void",
      valuetype = "void"
    },
    getTaskQueueWrap={
      type = "method",
      returns = "CSyncActiveQueueWrap",
      valuetype = "CSyncActiveQueueWrap"
    },
    start={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    needFree={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    setModuleConfig={
      type = "method",
      args = "IModuleConfig: config,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CModuleThreadLoopWrap = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CModuleThreadLoopWrap",
      valuetype = "CModuleThreadLoopWrap",
    },
    isUserIndex={
      type = "method",
      args = "unsigned long long: uid,",
      returns = "bool",
      valuetype = "bool"
    },
    isMaxUserNum={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    isRunning={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    setTagId={
      type = "method",
      args = "unsigned char: tagId,",
      returns = "void",
      valuetype = "void"
    },
    freeTask={
      type = "method",
      args = "CTask: arg,",
      returns = "void",
      valuetype = "void"
    },
    setService={
      type = "method",
      args = "GxService: service,",
      returns = "void",
      valuetype = "void"
    },
    stop={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    getTaskQueueWrap={
      type = "method",
      returns = "CSyncActiveQueueWrap",
      valuetype = "CSyncActiveQueueWrap"
    },
    getService={
      type = "method",
      returns = "GxService",
      valuetype = "GxService"
    },
    breath={
      type = "method",
      args = "int: diff,",
      returns = "void",
      valuetype = "void"
    },
    start={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    getMaxUserNum={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getModuleThreadLoop={
      type = "method",
      returns = "CModuleThreadLoop",
      valuetype = "CModuleThreadLoop"
    },
    isExitRun={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    genUniqueIndex={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    getUserNum={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getTagId={
      type = "method",
      returns = "unsigned char",
      valuetype = "unsigned char"
    },
    getOutputQSize={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
  },
},
CSimpleThreadLoopWrap = {
  type = "class",
  inherits = "CModuleThreadLoopWrap ",
},
CModuleBase = {
  type = "class",
  inherits = "IModuleManager ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CModuleBase",
      valuetype = "CModuleBase",
    },
    checkAllLoopStop={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getMaxConnNum={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    setService={
      type = "method",
      args = "GxService: service,",
      returns = "void",
      valuetype = "void"
    },
    getLeastLoop={
      type = "method",
      returns = "CModuleThreadLoopWrap",
      valuetype = "CModuleThreadLoopWrap"
    },
    getService={
      type = "method",
      returns = "GxService",
      valuetype = "GxService"
    },
    start={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    getLoopNum={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    onStop={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CLoopToThreadTask = {
  type = "class",
  inherits = "CTask ",
},
CThreadToLoopTask = {
  type = "class",
  inherits = "CTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CThreadToLoopTask",
      valuetype = "CThreadToLoopTask",
    },
    isSuccess={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getErrorCode={
      type = "method",
      returns = "short",
      valuetype = "short"
    },
    setSuccess={
      type = "method",
      args = "short: flag,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CDbConnTask = {
  type = "class",
  inherits = "CThreadToLoopTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CDbConnTask",
      valuetype = "CDbConnTask",
    },
    getDbUserIndex={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    getDbConnWrap={
      type = "method",
      returns = "CDatabaseConnWrap",
      valuetype = "CDatabaseConnWrap"
    },
    setDbUserIndex={
      type = "method",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CDbWrapTask = {
  type = "class",
  inherits = "CLoopToThreadTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CDbWrapTask",
      valuetype = "CDbWrapTask",
    },
    setDbUserIndex={
      type = "method",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
    getDbUserIndex={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    getDbConn={
      type = "method",
      returns = "CDatabaseConn",
      valuetype = "CDatabaseConn"
    },
    doRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CDbTaskConnected = {
  type = "class",
  inherits = "CDbConnTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CDbTaskConnected",
      valuetype = "CDbTaskConnected",
    },
    doRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CDbTaskClose = {
  type = "class",
  inherits = "CDbConnTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CDbTaskClose",
      valuetype = "CDbTaskClose",
    },
    doRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CDatabaseConn = {
  type = "class",
  inherits = "CModuleThreadLoop ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CDatabaseConn",
      valuetype = "CDatabaseConn",
    },
    stopMsgHandle={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setDbUrlInfo={
      type = "method",
      args = "string: dbHost,",
      args = "string: dbName,",
      args = "string: dbUser,",
      args = "string: dbPass,",
      returns = "void",
      valuetype = "void"
    },
    setStartParam={
      type = "method",
      args = "unsigned int: reconnInterval,",
      returns = "void",
      valuetype = "void"
    },
    onConntected={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    pushTask={
      type = "method",
      args = "CDbConnTask: task,",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
    onClose={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    isDelUser={
      type = "method",
      args = "unsigned long long: uid,",
      returns = "bool",
      valuetype = "bool"
    },
    ping={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    isEmptyConn={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    start={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    toString={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    reconnect={
      type = "method",
      args = "unsigned int: num,",
      returns = "bool",
      valuetype = "bool"
    },
    pushDelUser={
      type = "method",
      args = "unsigned long long: uid,",
      returns = "void",
      valuetype = "void"
    },
    isStopMsgHandle={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    isActive={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
  },
},
CDatabaseConnWrap = {
  type = "class",
  inherits = "CSimpleThreadLoopWrap ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CDatabaseConnWrap",
      valuetype = "CDatabaseConnWrap",
    },
    findUser={
      type = "method",
      args = "unsigned long long: index,",
      returns = "CDatabaseHandler",
      valuetype = "CDatabaseHandler"
    },
    setDbUrlInfo={
      type = "method",
      args = "string: dbHost,",
      args = "string: dbName,",
      args = "string: dbUser,",
      args = "string: dbPass,",
      returns = "void",
      valuetype = "void"
    },
    setStartParam={
      type = "method",
      args = "unsigned int: reconnInterval,",
      returns = "void",
      valuetype = "void"
    },
    getDbConn={
      type = "method",
      returns = "CDatabaseConn",
      valuetype = "CDatabaseConn"
    },
    isStop={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    addUser={
      type = "method",
      args = "unsigned long long: index,",
      args = "CDatabaseHandler: handler,",
      returns = "void",
      valuetype = "void"
    },
    pushTask={
      type = "method",
      args = "CDbWrapTask: task,",
      returns = "void",
      valuetype = "void"
    },
    setDbHostParam={
      type = "method",
      args = "CDbHostParam: dbParam,",
      returns = "void",
      valuetype = "void"
    },
    getDbConnMgr={
      type = "method",
      returns = "CDatabaseConnMgr",
      valuetype = "CDatabaseConnMgr"
    },
    onConnected={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    getDbHostID={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    start={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    removeUser={
      type = "method",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
    toString={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    setDbHostID={
      type = "method",
      args = "unsigned int: id,",
      returns = "void",
      valuetype = "void"
    },
    setTag={
      type = "method",
      args = "unsigned char: tag,",
      returns = "void",
      valuetype = "void"
    },
    getTag={
      type = "method",
      returns = "unsigned char",
      valuetype = "unsigned char"
    },
    onClose={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    isActive={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    handleClearAllUser={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
IScriptObject = {
  type = "class",
  inherits = "IFreeable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "IScriptObject",
      valuetype = "IScriptObject",
    },
    getScriptHandleClassName={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    sCall={
      type = "method",
      args = "char: functionName,",
      returns = "string",
      valuetype = "string"
    },
    setScriptHandleClassName={
      type = "method",
      args = "string: newObjectFuncName,",
      returns = "void",
      valuetype = "void"
    },
    isExistMember={
      type = "method",
      args = "char: functionName,",
      returns = "bool",
      valuetype = "bool"
    },
    vCall={
      type = "method",
      args = "char: functionName,",
      returns = "void",
      valuetype = "void"
    },
    bCall={
      type = "method",
      args = "char: functionName,",
      returns = "bool",
      valuetype = "bool"
    },
  },
},
IHandler = {
  type = "class",
  inherits = "IScriptObject ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "IHandler",
      valuetype = "IHandler",
    },
    reset={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    onDelete={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setParam={
      type = "method",
      args = "IAllocatable: allocable,",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
    handle={
      type = "method",
      args = "char: msg,",
      args = "unsigned int: len,",
      returns = "EHandleRet",
      valuetype = "EHandleRet"
    },
    setStarted={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    isValid={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getName={
      type = "method",
      returns = "char",
      valuetype = "char"
    },
    onReconnect={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    isStarted={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getUniqueIndex={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    breath={
      type = "method",
      args = "int: diff,",
      returns = "void",
      valuetype = "void"
    },
    start={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    close={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CDatabaseHandler = {
  type = "class",
  inherits = "IHandler ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CDatabaseHandler",
      valuetype = "CDatabaseHandler",
    },
    handle={
      type = "method",
      args = "char: msg,",
      args = "unsigned int: len,",
      returns = "EHandleRet",
      valuetype = "EHandleRet"
    },
    freeDatabaseTask={
      type = "method",
      args = "CDbWrapTask: task,",
      returns = "void",
      valuetype = "void"
    },
    getDbWrap={
      type = "method",
      returns = "CDatabaseConnWrap",
      valuetype = "CDatabaseConnWrap"
    },
    isValid={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    pushTask={
      type = "method",
      args = "CDbWrapTask: task,",
      returns = "void",
      valuetype = "void"
    },
    getTag={
      type = "method",
      returns = "unsigned char",
      valuetype = "unsigned char"
    },
    kick={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CDbHostParam = {
  type = "class",
},
CDatabaseConfig = {
  type = "class",
  inherits = "IModuleConfig ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CDatabaseConfig",
      valuetype = "CDatabaseConfig",
    },
    setCleanupParm={
      type = "method",
      args = "int: reconnInterval,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CDatabaseConnMgr = {
  type = "class",
  inherits = "CModuleBase ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CDatabaseConnMgr",
      valuetype = "CDatabaseConnMgr",
    },
    pushTask={
      type = "method",
      args = "CDbWrapTask: task,",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
    getUser={
      type = "method",
      args = "unsigned long long: index,",
      returns = "CDatabaseHandler",
      valuetype = "CDatabaseHandler"
    },
    removeUser={
      type = "method",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
    getConfig={
      type = "method",
      returns = "CDatabaseConfig",
      valuetype = "CDatabaseConfig"
    },
    size={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},
CGameTime = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CGameTime",
      valuetype = "CGameTime",
    },
    setGameTime={
      type = "method",
      args = "unsigned int: val,",
      returns = "void",
      valuetype = "void"
    },
    toString={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    getGameTime={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},
CMemInStream = {
  type = "class",
  inherits = "IUnStream ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CMemInStream",
      valuetype = "CMemInStream",
    },
    reset={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    getFreeSize={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    maxSize={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    curData={
      type = "method",
      returns = "char",
      valuetype = "char"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    data={
      type = "method",
      returns = "char",
      valuetype = "char"
    },
    size={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},
CMemOutStream = {
  type = "class",
  inherits = "IStream ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CMemOutStream",
      valuetype = "CMemOutStream",
    },
    reset={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    getFreeSize={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    maxSize={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    curData={
      type = "method",
      returns = "char",
      valuetype = "char"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    data={
      type = "method",
      returns = "char",
      valuetype = "char"
    },
    size={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},
CMemOutputStream = {
  type = "class",
  inherits = "CMemOutStream ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CMemOutputStream",
      valuetype = "CMemOutputStream",
    },
    writeInt8={
      type = "method",
      args = "char: val,",
      returns = "char",
      valuetype = "char"
    },
    writeUInt64ByPos={
      type = "method",
      args = "unsigned long long: val,",
      args = "int: pos,",
      returns = "char",
      valuetype = "char"
    },
    writeUInt64={
      type = "method",
      args = "unsigned long long: val,",
      returns = "char",
      valuetype = "char"
    },
    writeString={
      type = "method",
      args = "CScriptString: str,",
      returns = "short",
      valuetype = "short"
    },
    writeUInt16ByPos={
      type = "method",
      args = "unsigned short: val,",
      args = "int: pos,",
      returns = "char",
      valuetype = "char"
    },
    writeUInt16={
      type = "method",
      args = "unsigned short: val,",
      returns = "char",
      valuetype = "char"
    },
    writeInt64={
      type = "method",
      args = "long long: val,",
      returns = "char",
      valuetype = "char"
    },
    writeUInt8={
      type = "method",
      args = "unsigned char: val,",
      returns = "char",
      valuetype = "char"
    },
    writeInt32={
      type = "method",
      args = "int: val,",
      returns = "char",
      valuetype = "char"
    },
    getCurrentPos={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    writeUInt8ByPos={
      type = "method",
      args = "unsigned char: val,",
      args = "int: pos,",
      returns = "char",
      valuetype = "char"
    },
    writeUInt32ByPos={
      type = "method",
      args = "unsigned int: val,",
      args = "int: pos,",
      returns = "char",
      valuetype = "char"
    },
    writeBufferByPos={
      type = "method",
      args = "char: buf,",
      args = "unsigned int: len,",
      args = "unsigned int: pos,",
      returns = "bool",
      valuetype = "bool"
    },
    writeSString={
      type = "method",
      args = "CScriptString: str,",
      returns = "short",
      valuetype = "short"
    },
    writeUInt32={
      type = "method",
      args = "unsigned int: val,",
      returns = "char",
      valuetype = "char"
    },
    writeInt16={
      type = "method",
      args = "short: val,",
      returns = "char",
      valuetype = "char"
    },
  },
},
CMemInputStream = {
  type = "class",
  inherits = "CMemInStream ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CMemInputStream",
      valuetype = "CMemInputStream",
    },
    readUInt64={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    readInt32={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    peakUInt16={
      type = "method",
      args = "int: skipPos,",
      returns = "unsigned short",
      valuetype = "unsigned short"
    },
    readSString={
      type = "method",
      returns = "CScriptString",
      valuetype = "CScriptString"
    },
    peakUInt64={
      type = "method",
      args = "int: skipPos,",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    peakUInt8={
      type = "method",
      args = "int: skipPos,",
      returns = "unsigned char",
      valuetype = "unsigned char"
    },
    readInt16={
      type = "method",
      returns = "short",
      valuetype = "short"
    },
    readInt64={
      type = "method",
      returns = "long long",
      valuetype = "long long"
    },
    readUInt8={
      type = "method",
      returns = "unsigned char",
      valuetype = "unsigned char"
    },
    readString={
      type = "method",
      returns = "CScriptString",
      valuetype = "CScriptString"
    },
    readUInt32={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    peakBuffer={
      type = "method",
      args = "char: buff,",
      args = "unsigned int: len,",
      args = "unsigned int: skipPos,",
      returns = "bool",
      valuetype = "bool"
    },
    readUInt16={
      type = "method",
      returns = "unsigned short",
      valuetype = "unsigned short"
    },
    readInt8={
      type = "method",
      returns = "char",
      valuetype = "char"
    },
    peakUInt32={
      type = "method",
      args = "int: skipPos,",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},
dbColProxy = {
  type = "class",
},
TDBStructBase = {
  type = "class",
},
CIni = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CIni",
      valuetype = "CIni",
    },
    findIndex={
      type = "method",
      args = "char: ,",
      returns = "int",
      valuetype = "int"
    },
    getData={
      type = "method",
      returns = "char",
      valuetype = "char"
    },
    getContinueDataNum={
      type = "method",
      args = "char: section,",
      returns = "int",
      valuetype = "int"
    },
    readCaption={
      type = "method",
      args = "char: section,",
      args = "int: lines,",
      args = "char: str,",
      args = "int: size,",
      returns = "char",
      valuetype = "char"
    },
    returnLineNum={
      type = "method",
      args = "char: ,",
      returns = "int",
      valuetype = "int"
    },
    close={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    findOneLine={
      type = "method",
      args = "int: ,",
      returns = "int",
      valuetype = "int"
    },
    save={
      type = "method",
      args = "char: filename,",
      returns = "bool",
      valuetype = "bool"
    },
    readOneLine={
      type = "method",
      args = "int: ,",
      returns = "char",
      valuetype = "char"
    },
    readIntIfExist={
      type = "method",
      args = "char: section,",
      args = "char: key,",
      args = "int: nResult,",
      returns = "bool",
      valuetype = "bool"
    },
  },
},
IniItem = {
  type = "class",
},
CIniSection = {
  type = "class",
},
CLibConfig = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CLibConfig",
      valuetype = "CLibConfig",
    },
    getStatInterval={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    init={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setConfig={
      type = "method",
      args = "ELibConfig: config,",
      args = "unsigned int: flag,",
      returns = "void",
      valuetype = "void"
    },
    getStatDb={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    getConfig={
      type = "method",
      args = "ELibConfig: config,",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    isConfig={
      type = "method",
      args = "ELibConfig: config,",
      returns = "bool",
      valuetype = "bool"
    },
  },
},
SSocketLoopEventArg = {
  type = "class",
},
SMainLoopEventArg = {
  type = "class",
},
CSocketInputStream = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CSocketInputStream",
      valuetype = "CSocketInputStream",
    },
    peakUint={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    peakUint16={
      type = "method",
      returns = "unsigned short",
      valuetype = "unsigned short"
    },
    getBuffer={
      type = "method",
      returns = "char",
      valuetype = "char"
    },
    capacity={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getTailPos={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    peek={
      type = "method",
      args = "char: buf,",
      args = "int: len,",
      returns = "bool",
      valuetype = "bool"
    },
    read={
      type = "method",
      args = "char: buf,",
      args = "int: len,",
      returns = "int",
      valuetype = "int"
    },
    skip={
      type = "method",
      args = "int: len,",
      returns = "bool",
      valuetype = "bool"
    },
    peakByte={
      type = "method",
      returns = "char",
      valuetype = "char"
    },
    initsize={
      type = "method",
      args = "CSocket: sock,",
      args = "int: BufferLen,",
      args = "int: MaxBufferLen,",
      returns = "void",
      valuetype = "void"
    },
    length={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    peakInt={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    isEmpty={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getBuffLen={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getHeadPos={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    peakInt16={
      type = "method",
      returns = "short",
      valuetype = "short"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    size={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    resize={
      type = "method",
      args = "int: size,",
      returns = "bool",
      valuetype = "bool"
    },
    fill={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
  },
},
CSocketOutputStream = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CSocketOutputStream",
      valuetype = "CSocketOutputStream",
    },
    capacity={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getTailPos={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    write={
      type = "method",
      args = "char: buf,",
      args = "int: len,",
      returns = "int",
      valuetype = "int"
    },
    initsize={
      type = "method",
      args = "CSocket: sock,",
      args = "int: BufferSize,",
      args = "int: MaxBufferSize,",
      returns = "void",
      valuetype = "void"
    },
    length={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    isEmpty={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getBuffLen={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getHeadPos={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    flush={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getBuffer={
      type = "method",
      returns = "char",
      valuetype = "char"
    },
    getTail={
      type = "method",
      returns = "char",
      valuetype = "char"
    },
    resize={
      type = "method",
      args = "int: size,",
      returns = "bool",
      valuetype = "bool"
    },
    size={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
  },
},
CPackHandleAry = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CPackHandleAry",
      valuetype = "CPackHandleAry",
    },
    getPack={
      type = "method",
      args = "int: index,",
      returns = "char",
      valuetype = "char"
    },
    push={
      type = "method",
      args = "char: msg,",
      args = "int: len,",
      returns = "void",
      valuetype = "void"
    },
    getPackNum={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
  },
},
ISocketPacketHandler = {
  type = "class",
  inherits = "IFreeable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "ISocketPacketHandler",
      valuetype = "ISocketPacketHandler",
    },
    needHandle={
      type = "method",
      args = "EPackOpt: opt,",
      returns = "bool",
      valuetype = "bool"
    },
    isVarPacket={
      type = "method",
      args = "char: buff,",
      args = "int: len,",
      returns = "bool",
      valuetype = "bool"
    },
    sendPack={
      type = "method",
      args = "char: msg,",
      args = "unsigned int: len,",
      returns = "void",
      valuetype = "void"
    },
    onSendPack={
      type = "method",
      args = "char: buff,",
      args = "int: len,",
      args = "bool: singalFlag,",
      returns = "void",
      valuetype = "void"
    },
    onBeforeFlushToSocket={
      type = "method",
      args = "char: buff,",
      args = "int: len,",
      args = "char: outBuff,",
      args = "int: outLen,",
      returns = "int",
      valuetype = "int"
    },
    setSocket={
      type = "method",
      args = "CSocket: socket,",
      returns = "void",
      valuetype = "void"
    },
    getUnpacketNum={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    onHandleVarUnpacket={
      type = "method",
      args = "char: buff,",
      args = "char: varBuff,",
      args = "int: len,",
      returns = "void",
      valuetype = "void"
    },
    onAfterReadFromSocket={
      type = "method",
      args = "char: buff,",
      args = "int: len,",
      args = "char: outBuff,",
      args = "int: outLen,",
      returns = "int",
      valuetype = "int"
    },
    setUnpacketNum={
      type = "method",
      args = "int: unpacketNum,",
      returns = "void",
      valuetype = "void"
    },
    getMaxVarPackLen={
      type = "method",
      args = "char: buff,",
      returns = "int",
      valuetype = "int"
    },
    canUnpacket={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getPackHeaderLen={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getSocket={
      type = "method",
      returns = "CSocket",
      valuetype = "CSocket"
    },
    onPackAfterFromSocket={
      type = "method",
      args = "char: buff,",
      args = "int: len,",
      args = "char: outBuff,",
      args = "int: outLen,",
      returns = "int",
      valuetype = "int"
    },
    canReadPack={
      type = "method",
      args = "char: buff,",
      args = "int: len,",
      returns = "int",
      valuetype = "int"
    },
    onPackBeforeFlushToSocket={
      type = "method",
      args = "char: buff,",
      args = "int: len,",
      args = "char: outBuff,",
      args = "int: outLen,",
      returns = "int",
      valuetype = "int"
    },
    unpacket={
      type = "method",
      args = "CNetSocketLoopTask: task,",
      args = "char: packBuff,",
      args = "int: packBuffLen,",
      args = "char: packBuffTempRead,",
      args = "int: packBuffTempReadLen,",
      returns = "bool",
      valuetype = "bool"
    },
    onRecvPack={
      type = "method",
      args = "char: buff,",
      args = "int: len,",
      args = "bool: singalFlag,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CEmptyPacketHandler = {
  type = "class",
  inherits = "ISocketPacketHandler ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CEmptyPacketHandler",
      valuetype = "CEmptyPacketHandler",
    },
    unpacket={
      type = "method",
      args = "CNetSocketLoopTask: task,",
      args = "char: packBuff,",
      args = "int: packBuffLen,",
      args = "char: packBuffTempRead,",
      args = "int: packBuffTempReadLen,",
      returns = "bool",
      valuetype = "bool"
    },
    canUnpacket={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getPackHeaderLen={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
  },
},
CDefaultPacketHandler = {
  type = "class",
  inherits = "ISocketPacketHandler ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CDefaultPacketHandler",
      valuetype = "CDefaultPacketHandler",
    },
    unpacket={
      type = "method",
      args = "CNetSocketLoopTask: task,",
      args = "char: packBuff,",
      args = "int: packBuffLen,",
      args = "char: packBuffTempRead,",
      args = "int: packBuffTempReadLen,",
      returns = "bool",
      valuetype = "bool"
    },
    canUnpacket={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getPackHeaderLen={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
  },
},
CSocket = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CSocket",
      valuetype = "CSocket",
    },
    setWaitCloseSecs={
      type = "method",
      args = "unsigned int: secs,",
      returns = "void",
      valuetype = "void"
    },
    getSocket={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    setSocketEventLoop={
      type = "method",
      args = "CSocketEventLoop: loop,",
      returns = "void",
      valuetype = "void"
    },
    getOutputStream={
      type = "method",
      returns = "CSocketOutputStream",
      valuetype = "CSocketOutputStream"
    },
    getUniqueIndex={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    getReceiveBufferSize={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getUnpacketNum={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    cleanUp={
      type = "method",
      args = "CSocketEventLoop: loop,",
      returns = "void",
      valuetype = "void"
    },
    getInputLen={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getPacketHandler={
      type = "method",
      returns = "ISocketPacketHandler",
      valuetype = "ISocketPacketHandler"
    },
    close={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setLinger={
      type = "method",
      args = "int: lingertime,",
      returns = "bool",
      valuetype = "bool"
    },
    isNonBlocking={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getThreadID={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    create={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    setPacketHandler={
      type = "method",
      args = "ISocketPacketHandler: handler,",
      returns = "void",
      valuetype = "void"
    },
    setReceiveBufferSize={
      type = "method",
      args = "int: size,",
      returns = "bool",
      valuetype = "bool"
    },
    setReuseAddr={
      type = "method",
      args = "bool: on,",
      returns = "bool",
      valuetype = "bool"
    },
    write={
      type = "method",
      args = "char: msg,",
      args = "int: len,",
      returns = "int",
      valuetype = "int"
    },
    setUniqueIndex={
      type = "method",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
    isReuseAddr={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    toString={
      type = "method",
      returns = "char",
      valuetype = "char"
    },
    onRead={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getSendBufferSize={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    isSockError={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getOutputLen={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getPort={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getLinger={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    available={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    isNeedWrite={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    read={
      type = "method",
      args = "char: msg,",
      args = "int: len,",
      returns = "int",
      valuetype = "int"
    },
    isValid={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    setSocket={
      type = "method",
      args = "int: id,",
      returns = "void",
      valuetype = "void"
    },
    setActive={
      type = "method",
      args = "bool: flag,",
      returns = "void",
      valuetype = "void"
    },
    getSockError={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    setSendBufferSize={
      type = "method",
      args = "int: size,",
      returns = "bool",
      valuetype = "bool"
    },
    needDel={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    onWrite={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getRemotePort={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getWaitCloseSecs={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    getInputStream={
      type = "method",
      returns = "CSocketInputStream",
      valuetype = "CSocketInputStream"
    },
    reset={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setNonBlocking={
      type = "method",
      args = "bool: on,",
      returns = "bool",
      valuetype = "bool"
    },
    getSocketEventLoop={
      type = "method",
      returns = "CSocketEventLoop",
      valuetype = "CSocketEventLoop"
    },
    isActive={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    canUnpacket={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    unpacket={
      type = "method",
      args = "CNetSocketLoopTask: task,",
      args = "char: packBuff,",
      args = "int: packBuffLen,",
      args = "char: packBuffTempRead,",
      args = "int: packBuffTempReadLen,",
      returns = "bool",
      valuetype = "bool"
    },
  },
},
CNetSocketLoopTask = {
  type = "class",
  inherits = "CThreadToLoopTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CNetSocketLoopTask",
      valuetype = "CNetSocketLoopTask",
    },
    getNetLoopWrap={
      type = "method",
      returns = "CNetLoopWrap",
      valuetype = "CNetLoopWrap"
    },
    setSocketIndex={
      type = "method",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
    getSocketIndex={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
  },
},
CNetSocketLoopWrapTask = {
  type = "class",
  inherits = "CLoopToThreadTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CNetSocketLoopWrapTask",
      valuetype = "CNetSocketLoopWrapTask",
    },
    setSocketIndex={
      type = "method",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
    getSocketLoop={
      type = "method",
      returns = "CSocketEventLoop",
      valuetype = "CSocketEventLoop"
    },
    getSocketIndex={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
  },
},
CNetSendPacketTask = {
  type = "class",
  inherits = "CNetSocketLoopWrapTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CNetSendPacketTask",
      valuetype = "CNetSendPacketTask",
    },
    getName={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    doRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    type={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},
CNetRecvPacketTask = {
  type = "class",
  inherits = "CNetSocketLoopTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CNetRecvPacketTask",
      valuetype = "CNetRecvPacketTask",
    },
    getName={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    doRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CNetWrapBroadCastTask = {
  type = "class",
  inherits = "CNetSocketLoopWrapTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CNetWrapBroadCastTask",
      valuetype = "CNetWrapBroadCastTask",
    },
    doRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CBroadcastPacketTask = {
  type = "class",
  inherits = "CNetSocketLoopWrapTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CBroadcastPacketTask",
      valuetype = "CBroadcastPacketTask",
    },
    doRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CNetSocketClose = {
  type = "class",
  inherits = "CNetSocketLoopTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CNetSocketClose",
      valuetype = "CNetSocketClose",
    },
    doRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CNetSocketDelTask = {
  type = "class",
  inherits = "CNetSocketLoopWrapTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CNetSocketDelTask",
      valuetype = "CNetSocketDelTask",
    },
    doRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CNetSocketAddRet = {
  type = "class",
  inherits = "CNetSocketLoopTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CNetSocketAddRet",
      valuetype = "CNetSocketAddRet",
    },
    doRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CSocketEventLoop = {
  type = "class",
  inherits = "CModuleThreadLoop ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CSocketEventLoop",
      valuetype = "CSocketEventLoop",
    },
    stopMsgHandle={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setMsgPerFrame={
      type = "method",
      args = "unsigned int: msgPerFrame,",
      returns = "void",
      valuetype = "void"
    },
    pushTask={
      type = "method",
      args = "CNetSocketLoopTask: task,",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
    setBroadCastQ={
      type = "method",
      args = "CSyncActiveQueue: inputQ,",
      args = "CSyncActiveQueue: outputQ,",
      returns = "void",
      valuetype = "void"
    },
    handleDelSocket={
      type = "method",
      args = "unsigned long long: index,",
      args = "int: waitCloseSecs,",
      args = "int: noDataNeedDel,",
      returns = "void",
      valuetype = "void"
    },
    init={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    isStopMsgHandle={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    handleWriteMsg={
      type = "method",
      args = "unsigned long long: index,",
      args = "char: msg,",
      args = "unsigned int: len,",
      returns = "void",
      valuetype = "void"
    },
    getBroadcastQWrap={
      type = "method",
      returns = "CSyncActiveQueueWrap",
      valuetype = "CSyncActiveQueueWrap"
    },
  },
},
CNetLoopWrap = {
  type = "class",
  inherits = "CSimpleThreadLoopWrap ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CNetLoopWrap",
      valuetype = "CNetLoopWrap",
    },
    writeMsg={
      type = "method",
      args = "char: msg,",
      args = "int: len,",
      args = "unsigned long long: index,",
      args = "char: name,",
      returns = "void",
      valuetype = "void"
    },
    handlePacket={
      type = "method",
      args = "unsigned long long: index,",
      args = "char: msg,",
      args = "int: len,",
      returns = "void",
      valuetype = "void"
    },
    getNetConfig={
      type = "method",
      returns = "CNetModuleConfig",
      valuetype = "CNetModuleConfig"
    },
    getSocketEventLoop={
      type = "method",
      returns = "CSocketEventLoop",
      valuetype = "CSocketEventLoop"
    },
    delSocket={
      type = "method",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
    addSocket={
      type = "method",
      args = "CSocket: socket,",
      args = "CSocketHandler: handler,",
      returns = "void",
      valuetype = "void"
    },
    pushTask={
      type = "method",
      args = "CNetSocketLoopWrapTask: task,",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
    getSocketHandlerAll={
      type = "method",
      args = "unsigned long long: index,",
      returns = "CSocketHandler",
      valuetype = "CSocketHandler"
    },
    getUserNum={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getNetLoopWrapMgr={
      type = "method",
      returns = "CNetModule",
      valuetype = "CNetModule"
    },
    handleCloseSocket={
      type = "method",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
    getSocketHandler={
      type = "method",
      args = "unsigned long long: index,",
      returns = "CSocketHandler",
      valuetype = "CSocketHandler"
    },
    initBroadcastQ={
      type = "method",
      args = "CSyncActiveQueue: loopInputQ,",
      args = "CSyncActiveQueue: loopOutputQ,",
      returns = "void",
      valuetype = "void"
    },
    handleAddSocketRet={
      type = "method",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
    closeSocket={
      type = "method",
      args = "unsigned long long: index,",
      args = "int: waitSecs,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CSocketHandler = {
  type = "class",
  inherits = "IHandler ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CSocketHandler",
      valuetype = "CSocketHandler",
    },
    getString={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    flush={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setRemoteAddr={
      type = "method",
      args = "string: ip,",
      args = "int: port,",
      returns = "void",
      valuetype = "void"
    },
    getLocalPort={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getNetLoopWrap={
      type = "method",
      returns = "CNetLoopWrap",
      valuetype = "CNetLoopWrap"
    },
    setAddr={
      type = "method",
      args = "string: ip,",
      args = "int: port,",
      returns = "void",
      valuetype = "void"
    },
    getBufferStream={
      type = "method",
      returns = "CMemOutputStream",
      valuetype = "CMemOutputStream"
    },
    send={
      type = "method",
      args = "char: msg,",
      args = "int: len,",
      args = "char: name,",
      returns = "void",
      valuetype = "void"
    },
    breath={
      type = "method",
      args = "int: ,",
      returns = "void",
      valuetype = "void"
    },
    init={
      type = "method",
      args = "CNetLoopWrap: loopWrap,",
      args = "unsigned long long: index,",
      returns = "void",
      valuetype = "void"
    },
    kick={
      type = "method",
      args = "int: secs,",
      returns = "void",
      valuetype = "void"
    },
    onFlushData={
      type = "method",
      args = "char: msg,",
      args = "int: len,",
      returns = "bool",
      valuetype = "bool"
    },
    isScriptHandler={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getRemoteIp={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    getOtherHandler={
      type = "method",
      args = "unsigned long long: socketIndex,",
      returns = "CSocketHandler",
      valuetype = "CSocketHandler"
    },
    isValid={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getSocketIndex={
      type = "method",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    getLocalIp={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    getWaitSecs={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getRemotePort={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    reset={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    onDelete={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CScriptSocketHandler = {
  type = "class",
  inherits = "CSocketHandler ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CScriptSocketHandler",
      valuetype = "CScriptSocketHandler",
    },
    isScriptHandler={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    initScriptObject={
      type = "method",
      args = "CLuaVM: scriptEngine,",
      returns = "bool",
      valuetype = "bool"
    },
    handle={
      type = "method",
      args = "char: msg,",
      args = "unsigned int: len,",
      returns = "EHandleRet",
      valuetype = "EHandleRet"
    },
    start={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    close={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CSocketConnector = {
  type = "class",
  inherits = "CSocket ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CSocketConnector",
      valuetype = "CSocketConnector",
    },
    reconnect={
      type = "method",
      args = "char: host,",
      args = "unsigned short: port,",
      args = "unsigned int: diff,",
      returns = "bool",
      valuetype = "bool"
    },
    updateLastConnectTime={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    getReconnectDiff={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    setServerIP={
      type = "method",
      args = "string: val,",
      returns = "void",
      valuetype = "void"
    },
    getConnectDiff={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    setServerPort={
      type = "method",
      args = "unsigned short: val,",
      returns = "void",
      valuetype = "void"
    },
    toString={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    connect={
      type = "method",
      args = "char: host,",
      args = "unsigned short: port,",
      args = "unsigned int: diff,",
      returns = "bool",
      valuetype = "bool"
    },
    setReconnectDiff={
      type = "method",
      args = "int: diff,",
      returns = "void",
      valuetype = "void"
    },
    setConnectDiff={
      type = "method",
      args = "int: val,",
      returns = "void",
      valuetype = "void"
    },
    getServerIP={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    canReconnect={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getServerPort={
      type = "method",
      returns = "unsigned short",
      valuetype = "unsigned short"
    },
  },
},
CSocketListener = {
  type = "class",
  inherits = "CSocket ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CSocketListener",
      valuetype = "CSocketListener",
    },
    getBacklog={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    accept={
      type = "method",
      returns = "CSocket",
      valuetype = "CSocket"
    },
    start={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
  },
},
CSocketBroadCast = {
  type = "class",
  inherits = "CModuleThreadLoop ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CSocketBroadCast",
      valuetype = "CSocketBroadCast",
    },
    init={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CNetBroadcastWrap = {
  type = "class",
  inherits = "CSimpleThreadLoopWrap ",
},
CNetBroadcastModule = {
  type = "class",
  inherits = "CModuleBase ",
},
CServerTaskPool = {
  type = "class",
  inherits = "CModuleThreadLoop ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CServerTaskPool",
      valuetype = "CServerTaskPool",
    },
    newScriptRetTask={
      type = "method",
      args = "string: functionName,",
      returns = "CServerScriptRetTask",
      valuetype = "CServerScriptRetTask"
    },
    getScriptEngine={
      type = "method",
      returns = "CLuaVM",
      valuetype = "CLuaVM"
    },
    init={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    initBeforeRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CServerPoolTask = {
  type = "class",
  inherits = "CThreadToLoopTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CServerPoolTask",
      valuetype = "CServerPoolTask",
    },
    getTaskPoolWrap={
      type = "method",
      returns = "CServerTaskPoolWrap",
      valuetype = "CServerTaskPoolWrap"
    },
    setDebugInfo={
      type = "method",
      args = "string: str,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CServerPoolWrapTask = {
  type = "class",
  inherits = "CLoopToThreadTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CServerPoolWrapTask",
      valuetype = "CServerPoolWrapTask",
    },
    getServerTaskPool={
      type = "method",
      returns = "CServerTaskPool",
      valuetype = "CServerTaskPool"
    },
    setDebugInfo={
      type = "method",
      args = "string: str,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CSocketReconnectTask = {
  type = "class",
  inherits = "CServerPoolWrapTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CSocketReconnectTask",
      valuetype = "CSocketReconnectTask",
    },
    doRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CSocketReconnectRetTask = {
  type = "class",
  inherits = "CServerPoolTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CSocketReconnectRetTask",
      valuetype = "CSocketReconnectRetTask",
    },
    doRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CServerScriptRetTask = {
  type = "class",
  inherits = "CServerPoolTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CServerScriptRetTask",
      valuetype = "CServerScriptRetTask",
    },
    doRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CServerScriptTask = {
  type = "class",
  inherits = "CServerPoolWrapTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CServerScriptTask",
      valuetype = "CServerScriptTask",
    },
    doRun={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    newScriptRetTask={
      type = "method",
      args = "string: functionName,",
      returns = "CServerScriptRetTask",
      valuetype = "CServerScriptRetTask"
    },
  },
},
CServerTaskPoolWrap = {
  type = "class",
  inherits = "CSimpleThreadLoopWrap ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CServerTaskPoolWrap",
      valuetype = "CServerTaskPoolWrap",
    },
    newScriptTask={
      type = "method",
      returns = "CServerScriptTask",
      valuetype = "CServerScriptTask"
    },
  },
},
CServerTaskConfig = {
  type = "class",
  inherits = "IModuleConfig ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CServerTaskConfig",
      valuetype = "CServerTaskConfig",
    },
    getScriptFileName={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    getPoolNum={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
  },
},
CServerTaskPoolMgr = {
  type = "class",
  inherits = "CModuleBase ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CServerTaskPoolMgr",
      valuetype = "CServerTaskPoolMgr",
    },
    newScriptTask={
      type = "method",
      args = "string: scriptName,",
      returns = "CServerScriptTask",
      valuetype = "CServerScriptTask"
    },
    getLeastPoolWrap={
      type = "method",
      returns = "CServerTaskPoolWrap",
      valuetype = "CServerTaskPoolWrap"
    },
  },
},
CNetModuleConfig = {
  type = "class",
  inherits = "IModuleConfig ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CNetModuleConfig",
      valuetype = "CNetModuleConfig",
    },
    getPackTempReadBuffLen={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getPackBuffLen={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getPacketNumPerFrame={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
  },
},
CNetModule = {
  type = "class",
  inherits = "CModuleBase ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CNetModule",
      valuetype = "CNetModule",
    },
    addListener={
      type = "method",
      args = "CSocketListener: listener,",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    getLeastNetLoop={
      type = "method",
      returns = "CNetLoopWrap",
      valuetype = "CNetLoopWrap"
    },
    addConnector={
      type = "method",
      args = "CSocketConnector: connector,",
      returns = "bool",
      valuetype = "bool"
    },
    getConfig={
      type = "method",
      returns = "CNetModuleConfig",
      valuetype = "CNetModuleConfig"
    },
    getSocketHandler={
      type = "method",
      args = "unsigned long long: index,",
      returns = "CSocketHandler",
      valuetype = "CSocketHandler"
    },
    closeSocket={
      type = "method",
      args = "unsigned long long: index,",
      args = "int: waitSecs,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CSocketServerListener = {
  type = "class",
  inherits = "CSocketListener ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CSocketServerListener",
      valuetype = "CSocketServerListener",
    },
    accept={
      type = "method",
      args = "int: inputStreamLen,",
      args = "int: outputStreamLen,",
      args = "int: maxInputStreamLen,",
      args = "int: maxOutputStreamLen,",
      returns = "CSocket",
      valuetype = "CSocket"
    },
  },
},
CServiceTask = {
  type = "class",
  inherits = "IRunnable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CServiceTask",
      valuetype = "CServiceTask",
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setExcuteNumPerFrame={
      type = "method",
      args = "int: num,",
      returns = "void",
      valuetype = "void"
    },
    getType={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    getExcuteNumPerFrame={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    isUnlimited={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
  },
},
CServiceTaskQue = {
  type = "class",
  inherits = "IAllocatable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CServiceTaskQue",
      valuetype = "CServiceTaskQue",
    },
    pushTask={
      type = "method",
      args = "CServiceTask: task,",
      returns = "bool",
      valuetype = "bool"
    },
    update={
      type = "method",
      args = "int: diff,",
      returns = "void",
      valuetype = "void"
    },
    setExecuteNumPerFrame={
      type = "method",
      args = "int: num,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CGxServiceConfig = {
  type = "class",
  inherits = "IModuleConfig ",
},
CSerivceScriptObject = {
  type = "class",
  inherits = "IScriptObject ",
},
GxService = {
  type = "class",
  inherits = "IServiceModule ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "GxService",
      valuetype = "GxService",
    },
    load={
      type = "method",
      args = "string: serverName,",
      returns = "bool",
      valuetype = "bool"
    },
    getNetMgr={
      type = "method",
      returns = "CNetModule",
      valuetype = "CNetModule"
    },
    addLoad={
      type = "method",
      args = "string: configBuff,",
      returns = "bool",
      valuetype = "bool"
    },
    doScriptEvent={
      type = "method",
      args = "char: functionName,",
      returns = "void",
      valuetype = "void"
    },
    getNetBroadcast={
      type = "method",
      returns = "CNetBroadcastModule",
      valuetype = "CNetBroadcastModule"
    },
    getDbMgr={
      type = "method",
      returns = "CDatabaseConnMgr",
      valuetype = "CDatabaseConnMgr"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    addConnector={
      type = "method",
      args = "CSocketConnector: pConnector,",
      returns = "bool",
      valuetype = "bool"
    },
    openClientListener={
      type = "method",
      args = "char: hosts,",
      args = "unsigned short: port,",
      args = "int: tag,",
      returns = "bool",
      valuetype = "bool"
    },
    getServerTaskMgr={
      type = "method",
      returns = "CServerTaskPoolMgr",
      valuetype = "CServerTaskPoolMgr"
    },
    setScriptEngine={
      type = "method",
      args = "CLuaVM: scriptEngine,",
      returns = "void",
      valuetype = "void"
    },
    setOption={
      type = "method",
      args = "unsigned int: cfgOpt,",
      args = "unsigned int: val,",
      returns = "void",
      valuetype = "void"
    },
    openServerListener={
      type = "method",
      args = "char: hosts,",
      args = "unsigned short: port,",
      args = "int: tag,",
      returns = "bool",
      valuetype = "bool"
    },
    openClientConnector={
      type = "method",
      args = "char: hosts,",
      args = "unsigned short: port,",
      args = "unsigned int: diff,",
      args = "int: tag,",
      args = "bool: blockFlag,",
      returns = "bool",
      valuetype = "bool"
    },
    start={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    test={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    closeSocket={
      type = "method",
      args = "unsigned long long: index,",
      args = "int: waitSecs,",
      returns = "void",
      valuetype = "void"
    },
    setMainScriptName={
      type = "method",
      args = "string: scriptName,",
      returns = "void",
      valuetype = "void"
    },
    addReconnector={
      type = "method",
      args = "CSocketConnector: pConnector,",
      returns = "bool",
      valuetype = "bool"
    },
    getModuleName={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    getServiceName={
      type = "method",
      returns = "string",
      valuetype = "string"
    },
    setNewServiceFunctionName={
      type = "method",
      args = "string: scriptFuncName,",
      returns = "void",
      valuetype = "void"
    },
    addLogger={
      type = "method",
      args = "IDisplayer: displayer,",
      returns = "void",
      valuetype = "void"
    },
    doServerEvent={
      type = "method",
      args = "char: functionName,",
      returns = "void",
      valuetype = "void"
    },
    setSystemEnvironment={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getTaskQue={
      type = "method",
      returns = "CServiceTaskQue",
      valuetype = "CServiceTaskQue"
    },
    getScriptEngine={
      type = "method",
      returns = "CLuaVM",
      valuetype = "CLuaVM"
    },
    getServiceConfig={
      type = "method",
      returns = "CGxServiceConfig",
      valuetype = "CGxServiceConfig"
    },
    getConfigMap={
      type = "method",
      returns = "CConfigMap",
      valuetype = "CConfigMap"
    },
    addTimer={
      type = "method",
      args = "CIntervalTimer: timer,",
      args = "bool: isNeedFree,",
      returns = "void",
      valuetype = "void"
    },
    setStopSigno={
      type = "method",
      args = "int: signo,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CMiniServer = {
  type = "class",
  inherits = "GxService ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CMiniServer",
      valuetype = "CMiniServer",
    },
    onAfterLoad={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    onSystemEnvironment={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    onAfterInit={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
  },
},
ManCore = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "ManCore",
      valuetype = "ManCore",
    },
  },
},
CSocketServerConnector = {
  type = "class",
  inherits = "CSocketConnector ",
},
CUnsensitiveSStringLessPred = {
  type = "class",
  inherits = "less<GXMISC::CSString> ",
},
CUnsensitiveStrLessPred = {
  type = "class",
},
FiledVar = {
  type = "class",
},
ITimer = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "ITimer",
      valuetype = "ITimer",
    },
    invalidFunc={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    beginTriggerFunc={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    endTriggerFunc={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
  },
},
CTimerBase = {
  type = "class",
  inherits = "ITimer ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CTimerBase",
      valuetype = "CTimerBase",
    },
    getLastStartTime={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    registeInvalidFunc={
      type = "method",
      args = "string: func,",
      returns = "void",
      valuetype = "void"
    },
    isStop={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getEndTime={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    cleanUp={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setEndTime={
      type = "method",
      args = "unsigned int: val,",
      returns = "void",
      valuetype = "void"
    },
    setTimerType={
      type = "method",
      args = "ETimerType: val,",
      returns = "void",
      valuetype = "void"
    },
    isInInterval={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getStartTime={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    getCallTimes={
      type = "method",
      returns = "int",
      valuetype = "int"
    },
    pause={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    isRun={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    resume={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    getTimerID={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    registeEndFunc={
      type = "method",
      args = "string: func,",
      returns = "void",
      valuetype = "void"
    },
    setStatus={
      type = "method",
      args = "ETimerStatus: val,",
      returns = "void",
      valuetype = "void"
    },
    initInterval={
      type = "method",
      args = "int: interval,",
      args = "int: seconds,",
      args = "int: mins,",
      args = "int: hour,",
      args = "int: day,",
      args = "int: month,",
      args = "int: year,",
      returns = "void",
      valuetype = "void"
    },
    registeAll={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    registeBeginFunc={
      type = "method",
      args = "string: func,",
      returns = "void",
      valuetype = "void"
    },
    isNeedSave={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    onInvalid={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    run={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    setTimerID={
      type = "method",
      args = "unsigned int: val,",
      returns = "void",
      valuetype = "void"
    },
    getNextStartSeconds={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    initTime={
      type = "method",
      args = "unsigned int: startTime,",
      args = "unsigned int: endTime,",
      args = "int: callTimes,",
      returns = "void",
      valuetype = "void"
    },
    stop={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    update={
      type = "method",
      args = "int: diff,",
      returns = "void",
      valuetype = "void"
    },
    getCreateTime={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    isPause={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getLastActiveTime={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    needStart={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getStatus={
      type = "method",
      returns = "ETimerStatus",
      valuetype = "ETimerStatus"
    },
    isInvalid={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getTimerType={
      type = "method",
      returns = "ETimerType",
      valuetype = "ETimerType"
    },
    isInTimer={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    setStartTime={
      type = "method",
      args = "unsigned int: val,",
      returns = "void",
      valuetype = "void"
    },
    setCallTimes={
      type = "method",
      args = "int: val,",
      returns = "void",
      valuetype = "void"
    },
    setLastActiveTime={
      type = "method",
      args = "unsigned int: val,",
      returns = "void",
      valuetype = "void"
    },
    setCreateTime={
      type = "method",
      args = "unsigned int: val,",
      returns = "void",
      valuetype = "void"
    },
    callScriptFunc={
      type = "method",
      args = "string: func,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CTimerAT = {
  type = "class",
  inherits = "CTimerBase ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CTimerAT",
      valuetype = "CTimerAT",
    },
    setTimeType={
      type = "method",
      args = "EATimeType: val,",
      returns = "void",
      valuetype = "void"
    },
    update={
      type = "method",
      args = "int: diff,",
      returns = "void",
      valuetype = "void"
    },
    defaultInInterval={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getTimeType={
      type = "method",
      returns = "EATimeType",
      valuetype = "EATimeType"
    },
    isInInterval={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
  },
},
CTimerATD = {
  type = "class",
  inherits = "CTimerAT ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CTimerATD",
      valuetype = "CTimerATD",
    },
    getLastStartTime={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},
CTimerATW = {
  type = "class",
  inherits = "CTimerAT ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CTimerATW",
      valuetype = "CTimerATW",
    },
    needStart={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getLastStartTime={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},
CTimerATM = {
  type = "class",
  inherits = "CTimerAT ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CTimerATM",
      valuetype = "CTimerATM",
    },
    needStart={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getLastStartTime={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},
CTimerIT = {
  type = "class",
  inherits = "CTimerBase ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CTimerIT",
      valuetype = "CTimerIT",
    },
    needStart={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    isInInterval={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
  },
},
CTimerManager = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CTimerManager",
      valuetype = "CTimerManager",
    },
    saveTimer={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    removeTimer={
      type = "method",
      args = "unsigned int: timerID,",
      returns = "void",
      valuetype = "void"
    },
    update={
      type = "method",
      args = "int: diff,",
      returns = "void",
      valuetype = "void"
    },
    isTimerExist={
      type = "method",
      args = "unsigned int: timerID,",
      returns = "bool",
      valuetype = "bool"
    },
    registeIT={
      type = "method",
      args = "unsigned int: startTime,",
      args = "unsigned int: endTime,",
      returns = "CTimerBase",
      valuetype = "CTimerBase"
    },
    loadTimer={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    getTimer={
      type = "method",
      args = "unsigned int: timerID,",
      returns = "CTimerBase",
      valuetype = "CTimerBase"
    },
    genTimerID={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    registe={
      type = "method",
      args = "CTimerBase: baseTimer,",
      args = "bool: needFree,",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},
CGameTimerInterface = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CGameTimerInterface",
      valuetype = "CGameTimerInterface",
    },
    isNeedBegin={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    getIsNeedBegin={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    setIsNeedBegin={
      type = "method",
      args = "bool: val,",
      returns = "void",
      valuetype = "void"
    },
    setLastActiveTime={
      type = "method",
      args = "unsigned int: val,",
      returns = "void",
      valuetype = "void"
    },
    getLastActiveTime={
      type = "method",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},
CGameTimerBase = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CGameTimerBase",
      valuetype = "CGameTimerBase",
    },
    isInvalid={
      type = "method",
      returns = "bool",
      valuetype = "bool"
    },
    update={
      type = "method",
      args = "unsigned int: diff,",
      returns = "void",
      valuetype = "void"
    },
  },
},
CGamePassTimerBase = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "",
      returns = "CGamePassTimerBase",
      valuetype = "CGamePassTimerBase",
    },
    updateTimer={
      type = "method",
      args = "unsigned int: diff,",
      returns = "void",
      valuetype = "void"
    },
    onPassWeekday={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    onPassDay={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    onPassMonth={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
    initTimer={
      type = "method",
      args = "unsigned int: lastTime,",
      returns = "bool",
      valuetype = "bool"
    },
    onPassHour={
      type = "method",
      returns = "void",
      valuetype = "void"
    },
  },
},
CUCStringHashMapTraits = {
  type = "class",
},
}
end