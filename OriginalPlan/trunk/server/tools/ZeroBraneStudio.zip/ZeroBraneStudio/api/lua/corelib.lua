require "api/lua/cpprootdir"
require "api/lua/cppapi"

do return{

CFixNullBase = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CFixNullBase",
      valuetype = "CFixNullBase",
    },
  },
},

CFixLenBase = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CFixLenBase",
      valuetype = "CFixLenBase",
    },
  },
},

IStreamable = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IStreamable",
      valuetype = "IStreamable",
    },
  },
},

IUnStreamable = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IUnStreamable",
      valuetype = "IUnStreamable",
    },
  },
},

IStreamableAll = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IStreamableAll",
      valuetype = "IStreamableAll",
    },
  },
},

IStream = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IStream",
      valuetype = "IStream",
    },
  },
},

IUnStream = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IUnStream",
      valuetype = "IUnStream",
    },
  },
},

ILockable = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "ILockable",
      valuetype = "ILockable",
    },
    leave={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    enter={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CEmptyLock = {
  type = "class",
  inherits = "ILockable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CEmptyLock",
      valuetype = "CEmptyLock",
    },
    leave={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    enter={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CUnfairMutex = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CUnfairMutex",
      valuetype = "CUnfairMutex",
    },
    leave={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    enter={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CFastLock = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CFastLock",
      valuetype = "CFastLock",
    },
    Set={
      type = "method",
      args="(unsigned int: lockVar,int: val)",
      returns = "void",
      valuetype = "void"
    },
    unlock={
      type = "method",
      args="(unsigned int: lockVar)",
      returns = "void",
      valuetype = "void"
    },
    Increase={
      type = "method",
      args="(unsigned int: lockVar,int: val)",
      returns = "void",
      valuetype = "void"
    },
    isLocked={
      type = "method",
      args="(unsigned int: lockVar)",
      returns = "bool",
      valuetype = "bool"
    },
    tryLock={
      type = "method",
      args="(unsigned int: lockVar)",
      returns = "bool",
      valuetype = "bool"
    },
    Descrease={
      type = "method",
      args="(unsigned int: lockVar,int: val)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CFairMutex = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CFairMutex",
      valuetype = "CFairMutex",
    },
    leave={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    enter={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CTimeVal = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CTimeVal",
      valuetype = "CTimeVal",
    },
    toTimeVal={
      type = "method",
      args="()",
      returns = "timeval*",
      valuetype = "timeval"
    },
  },
},

CTime = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CTime",
      valuetype = "CTime",
    },
    TicksToSecond={
      type = "method",
      args="(long long: ticks)",
      returns = "double",
      valuetype = "double"
    },
    GetHumanRelativeTime={
      type = "method",
      args="(int: nbSeconds)",
      returns = "string",
      valuetype = "string"
    },
    GetPerformanceTime={
      type = "method",
      args="()",
      returns = "long long",
      valuetype = "long long"
    },
    GetLocalTime={
      type = "method",
      args="()",
      returns = "long long",
      valuetype = "long long"
    },
    GetSecondsSince1970={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},

CTimespan = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CTimespan",
      valuetype = "CTimespan",
    },
    reset={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    totalHours={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    seconds={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    days={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    hours={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    totalMinutes={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getTimeSpan={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    totalSeconds={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    minutes={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
  },
},

CDateTime = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CDateTime",
      valuetype = "CDateTime",
    },
    week={
      type = "method",
      args="(int: firstDayOfWeek)",
      returns = "int",
      valuetype = "int"
    },
    dayOfWeek={
      type = "method",
      args="()",
      returns = "EDaysOfWeek",
      valuetype = "EDaysOfWeek"
    },
    isAM={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    totalMins={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    totalDays={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    hour={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    isPM={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    totalSecs={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    minute={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    update={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    month={
      type = "method",
      args="()",
      returns = "EMonths",
      valuetype = "EMonths"
    },
    totalHours={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    hourAMPM={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    second={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    dayOfYear={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    year={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    utcTime={
      type = "method",
      args="()",
      returns = "long long",
      valuetype = "long long"
    },
    day={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    IsValid={
      type = "method",
      args="(int: year,int: month,int: day,int: hour,int: minute,int: second)",
      returns = "bool",
      valuetype = "bool"
    },
    DaysOfMonth={
      type = "method",
      args="(int: year,int: month)",
      returns = "int",
      valuetype = "int"
    },
    ToWeak={
      type = "method",
      args="(int: wday)",
      returns = "EDaysOfWeek",
      valuetype = "EDaysOfWeek"
    },
    IsLeapYear={
      type = "method",
      args="(int: year)",
      returns = "bool",
      valuetype = "bool"
    },
  },
},

CTimeManager = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CTimeManager",
      valuetype = "CTimeManager",
    },
    getWeek={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getHour={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getYear={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getMonth={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    time2Number={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    nowSysTime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    getSecond={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    update={
      type = "method",
      args="()",
      returns = "long long",
      valuetype = "long long"
    },
    getDay={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    runTime={
      type = "method",
      args="()",
      returns = "long long",
      valuetype = "long long"
    },
    getMinute={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    localTime={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    nowAppTime={
      type = "method",
      args="()",
      returns = "long long",
      valuetype = "long long"
    },
    getANSITime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    startAppTime={
      type = "method",
      args="()",
      returns = "long long",
      valuetype = "long long"
    },
    getTodayTime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    getLocalWeek={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getLocalMonth={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getDayTime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    currentDate={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    getHumanRelativeTime={
      type = "method",
      args="(int: nbSeconds)",
      returns = "string",
      valuetype = "string"
    },
    LocalNowTime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    GetTimeUTCDiff={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    FormatSystemTime={
      type = "method",
      args="(long long: times,string: str)",
      returns = "void",
      valuetype = "void"
    },
    DiffTime={
      type = "method",
      args="(unsigned int: Date1,unsigned int: Date2)",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    SysNowTime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    ConvertTU={
      type = "method",
      args="(tm*: TM,unsigned int: Date)",
      returns = "void",
      valuetype = "void"
    },
    FormatTodayTime={
      type = "method",
      args="(unsigned int: nTime)",
      returns = "bool",
      valuetype = "bool"
    },
    ConvertUT={
      type = "method",
      args="(unsigned int: Date,tm*: TM)",
      returns = "void",
      valuetype = "void"
    },
    GxToAnsiTime={
      type = "method",
      args="(unsigned int: times)",
      returns = "long long",
      valuetype = "long long"
    },
    AppNowTime={
      type = "method",
      args="()",
      returns = "long long",
      valuetype = "long long"
    },
    AnsiToGxTime={
      type = "method",
      args="(long long: times)",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},

CGxContext = {
  type = "class",
  inherits = "CManualSingleton<GXMISC::CGxContext> ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CGxContext",
      valuetype = "CGxContext",
    },
    getMainThread={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    getStopSigno={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    getStopHandler={
      type = "method",
      args="()",
      returns = "IStopHandler*",
      valuetype = "IStopHandler"
    },
    callOnCrash={
      type = "method",
      args="(string: dumpName)",
      returns = "void",
      valuetype = "void"
    },
    clear={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    getMainLog={
      type = "method",
      args="()",
      returns = "CLogger*",
      valuetype = "CLogger"
    },
    update={
      type = "method",
      args="(unsigned int: diff)",
      returns = "void",
      valuetype = "void"
    },
    getFastLogThread={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    init={
      type = "method",
      args="(string: serverName)",
      returns = "bool",
      valuetype = "bool"
    },
    setFastLogThread={
      type = "method",
      args="(unsigned long long: threadID)",
      returns = "void",
      valuetype = "void"
    },
    setServerName={
      type = "method",
      args="(string: serverName)",
      returns = "void",
      valuetype = "void"
    },
    getServerName={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    setStopSigno={
      type = "method",
      args="(unsigned int: sig)",
      returns = "void",
      valuetype = "void"
    },
    setDumpHandler={
      type = "method",
      args="(IDumpHandler*: dumpHandler)",
      returns = "void",
      valuetype = "void"
    },
    setStopHandler={
      type = "method",
      args="(IStopHandler*: stopHandler)",
      returns = "void",
      valuetype = "void"
    },
    exitCallback={
      type = "method",
      args="(EExitCode: code)",
      returns = "void",
      valuetype = "void"
    },
    StopService={
      type = "method",
      args="(int: signo)",
      returns = "void",
      valuetype = "void"
    },
    GetStack={
      type = "method",
      args="(string: str)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CLogger = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CLogger",
      valuetype = "CLogger",
    },
    addNegativeFilter={
      type = "method",
      args="(char*: filterstr)",
      returns = "void",
      valuetype = "void"
    },
    displayFilter={
      type = "method",
      args="(CLogger*: log)",
      returns = "void",
      valuetype = "void"
    },
    resetFilters={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    flush={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    attached={
      type = "method",
      args="(IDisplayer*: displayer)",
      returns = "bool",
      valuetype = "bool"
    },
    update={
      type = "method",
      args="(unsigned int: diff)",
      returns = "void",
      valuetype = "void"
    },
    removeFilter={
      type = "method",
      args="(char*: filterstr)",
      returns = "void",
      valuetype = "void"
    },
    addPositiveFilter={
      type = "method",
      args="(char*: filterstr)",
      returns = "void",
      valuetype = "void"
    },
    synLog={
      type = "method",
      args="(string: str)",
      returns = "void",
      valuetype = "void"
    },
    calcLogNum={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    setPosition={
      type = "method",
      args="(ELogType: logType,bool: unrepeat,int: line,char*: fileName,char*: funcName,char*: module,bool: isSync)",
      returns = "void",
      valuetype = "void"
    },
    getDisplayer={
      type = "method",
      args="(char*: displayerName)",
      returns = "IDisplayer*",
      valuetype = "IDisplayer"
    },
    addDisplayer={
      type = "method",
      args="(IDisplayer*: displayer,bool: bypassFilter)",
      returns = "void",
      valuetype = "void"
    },
    noDisplayer={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    SetProcessName={
      type = "method",
      args="(string: processName)",
      returns = "void",
      valuetype = "void"
    },
    SetDefaultProcessName={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CSafeLog = {
  type = "class",
  inherits = "CLogger ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSafeLog",
      valuetype = "CSafeLog",
    },
  },
},

IDisplayer = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IDisplayer",
      valuetype = "IDisplayer",
    },
    leave={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    isNeedDeleteByLog={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getName={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    enter={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    LogTypeToString={
      type = "method",
      args="(ELogType: logType,bool: longFormat)",
      returns = "char*",
      valuetype = "char"
    },
    IsSyncString={
      type = "method",
      args="(bool: sync)",
      returns = "char*",
      valuetype = "char"
    },
    DateToComputerString={
      type = "method",
      args="(long long: date)",
      returns = "char*",
      valuetype = "char"
    },
  },
},

CStdDisplayer = {
  type = "class",
  inherits = "IDisplayer ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CStdDisplayer",
      valuetype = "CStdDisplayer",
    },
  },
},

CSafeStdDisplayer = {
  type = "class",
  inherits = "CStdDisplayer ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSafeStdDisplayer",
      valuetype = "CSafeStdDisplayer",
    },
    leave={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    enter={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CFileDisplayer = {
  type = "class",
  inherits = "IDisplayer ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CFileDisplayer",
      valuetype = "CFileDisplayer",
    },
    setParam={
      type = "method",
      args="(string: displayerName,unsigned int: size,bool: eraseLastLog)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CSafeFileDispalyer = {
  type = "class",
  inherits = "CFileDisplayer ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSafeFileDispalyer",
      valuetype = "CSafeFileDispalyer",
    },
    leave={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    enter={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CBit8 = {
  type = "class",
  inherits = "CFixBitSet<8> ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CBit8",
      valuetype = "CBit8",
    },
    toUInt8={
      type = "method",
      args="()",
      returns = "unsigned char",
      valuetype = "unsigned char"
    },
  },
},

CBit16 = {
  type = "class",
  inherits = "CFixBitSet<16> ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CBit16",
      valuetype = "CBit16",
    },
    toUInt16={
      type = "method",
      args="()",
      returns = "unsigned short",
      valuetype = "unsigned short"
    },
  },
},

CBit32 = {
  type = "class",
  inherits = "CFixBitSet<32> ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CBit32",
      valuetype = "CBit32",
    },
    toUInt32={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},

CBit64 = {
  type = "class",
  inherits = "CFixBitSet<64> ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CBit64",
      valuetype = "CBit64",
    },
    toUInt64={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
  },
},

CCPUTimeStat = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CCPUTimeStat",
      valuetype = "CCPUTimeStat",
    },
    getProcessSystemLoad={
      type = "method",
      args="(TMeasureType: type)",
      returns = "float",
      valuetype = "float"
    },
    getProcessCSystemLoad={
      type = "method",
      args="(TMeasureType: type)",
      returns = "float",
      valuetype = "float"
    },
    getCPUNiceLoad={
      type = "method",
      args="(TMeasureType: type)",
      returns = "float",
      valuetype = "float"
    },
    getProcessCUserLoad={
      type = "method",
      args="(TMeasureType: type)",
      returns = "float",
      valuetype = "float"
    },
    getCPUIOWaitLoad={
      type = "method",
      args="(TMeasureType: type)",
      returns = "float",
      valuetype = "float"
    },
    getCPUUserLoad={
      type = "method",
      args="(TMeasureType: type)",
      returns = "float",
      valuetype = "float"
    },
    getProcessCLoad={
      type = "method",
      args="(TMeasureType: type)",
      returns = "float",
      valuetype = "float"
    },
    getProcessLoad={
      type = "method",
      args="(TMeasureType: type)",
      returns = "float",
      valuetype = "float"
    },
    peekMeasures={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    getCPUSystemLoad={
      type = "method",
      args="(TMeasureType: type)",
      returns = "float",
      valuetype = "float"
    },
    getCPULoad={
      type = "method",
      args="(TMeasureType: type)",
      returns = "float",
      valuetype = "float"
    },
    getProcessUserLoad={
      type = "method",
      args="(TMeasureType: type)",
      returns = "float",
      valuetype = "float"
    },
    getPIDTicks={
      type = "method",
      args="(unsigned long long: utime,unsigned long long: stime,unsigned long long: cutime,unsigned long long: cstime,unsigned int: pid)",
      returns = "bool",
      valuetype = "bool"
    },
    getCPUTicks={
      type = "method",
      args="(unsigned long long: user,unsigned long long: nice,unsigned long long: system,unsigned long long: idle,unsigned long long: iowait)",
      returns = "bool",
      valuetype = "bool"
    },
  },
},

CSimpleAllocator = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSimpleAllocator",
      valuetype = "CSimpleAllocator",
    },
    alloc={
      type = "method",
      args="(int: n)",
      returns = "char*",
      valuetype = "char"
    },
    getTotalAllocSize={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    setThreadID={
      type = "method",
      args="(unsigned long long: tid)",
      returns = "void",
      valuetype = "void"
    },
    free={
      type = "method",
      args="(char*: p)",
      returns = "void",
      valuetype = "void"
    },
  },
},

IStopHandler = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IStopHandler",
      valuetype = "IStopHandler",
    },
    setStop={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setStart={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    onStop={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    isStop={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
  },
},

IRunnable = {
  type = "class",
  inherits = "IStopHandler ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IRunnable",
      valuetype = "IRunnable",
    },
    run={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setName={
      type = "method",
      args="(string: name)",
      returns = "void",
      valuetype = "void"
    },
    getThreadID={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    getName={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setThreadID={
      type = "method",
      args="(unsigned long long: tid)",
      returns = "void",
      valuetype = "void"
    },
    isExitRun={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    setExitRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

IAllocatable = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IAllocatable",
      valuetype = "IAllocatable",
    },
    allocArg={
      type = "method",
      args="(unsigned int: size)",
      returns = "char*",
      valuetype = "char"
    },
    freeArg={
      type = "method",
      args="(char*: arg)",
      returns = "void",
      valuetype = "void"
    },
  },
},

ISyncable = {
  type = "class",
  inherits = "IRunnable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "ISyncable",
      valuetype = "ISyncable",
    },
    setUsed={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    doAfterUsed={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    doAfterFromQueue={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setFreed={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    doBeforeToQueueue={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    canFree={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
  },
},

IFreeable = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IFreeable",
      valuetype = "IFreeable",
    },
    isNeedFree={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    setNeedFree={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

IDumpHandler = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IDumpHandler",
      valuetype = "IDumpHandler",
    },
    onDump={
      type = "method",
      args="(string: dumpName)",
      returns = "void",
      valuetype = "void"
    },
  },
},

ISimpleNoncopyable = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "ISimpleNoncopyable",
      valuetype = "ISimpleNoncopyable",
    },
  },
},

INoncopyable = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "INoncopyable",
      valuetype = "INoncopyable",
    },
  },
},

CDebugControl = {
  type = "class",
  inherits = "CManualSingleton<GXMISC::CDebugControl> ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CDebugControl",
      valuetype = "CDebugControl",
    },
    setTaskVar={
      type = "method",
      args="(bool: val)",
      returns = "void",
      valuetype = "void"
    },
    getDatabaseProfileVar={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    setDatabaseProfileVar={
      type = "method",
      args="(bool: val)",
      returns = "void",
      valuetype = "void"
    },
    getServiceStopVar={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getTaskBlockAllocVar={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    setServiceStopVar={
      type = "method",
      args="(bool: val)",
      returns = "void",
      valuetype = "void"
    },
    setTaskProfileVar={
      type = "method",
      args="(bool: val)",
      returns = "void",
      valuetype = "void"
    },
    getTaskProfileVar={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    setMainLoopProfileVar={
      type = "method",
      args="(bool: val)",
      returns = "void",
      valuetype = "void"
    },
    setTaskBlockAllocVar={
      type = "method",
      args="(bool: val)",
      returns = "void",
      valuetype = "void"
    },
    addHandler={
      type = "method",
      args="(unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
    setSocketProfileVar={
      type = "method",
      args="(bool: val)",
      returns = "void",
      valuetype = "void"
    },
    getSocketLoopProfileVar={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getSocketProfileVar={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    setSocketLoopProfileVar={
      type = "method",
      args="(bool: val)",
      returns = "void",
      valuetype = "void"
    },
    isHandler={
      type = "method",
      args="(unsigned long long: index)",
      returns = "bool",
      valuetype = "bool"
    },
    getMainLoopProfileVar={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getSocketBufferVar={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getTaskVar={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    setSocketBufferVar={
      type = "method",
      args="(bool: val)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CTask = {
  type = "class",
  inherits = "ISyncable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CTask",
      valuetype = "CTask",
    },
    doAfterUsed={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setTaskQueueWrap={
      type = "method",
      args="(CSyncActiveQueueWrap*: wrap)",
      returns = "void",
      valuetype = "void"
    },
    doRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    getLoopThread={
      type = "method",
      args="()",
      returns = "CModuleThreadLoop*",
      valuetype = "CModuleThreadLoop"
    },
    getArgNum={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    setPriority={
      type = "method",
      args="(unsigned char: prority)",
      returns = "void",
      valuetype = "void"
    },
    setObjUID={
      type = "method",
      args="(unsigned long long: uid)",
      returns = "void",
      valuetype = "void"
    },
    getArgLen={
      type = "method",
      args="(unsigned int: index)",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    getStartTime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    allocArg={
      type = "method",
      args="(unsigned int: size)",
      returns = "char*",
      valuetype = "char"
    },
    getName={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    setLoopThreadWrap={
      type = "method",
      args="(CModuleThreadLoopWrap*: loopThreadWrap)",
      returns = "void",
      valuetype = "void"
    },
    addArg={
      type = "method",
      args="(char*: arg,unsigned int: argLen)",
      returns = "void",
      valuetype = "void"
    },
    getPriority={
      type = "method",
      args="()",
      returns = "unsigned char",
      valuetype = "unsigned char"
    },
    getTotalArgLen={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    type={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    run={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    getLoopThreadWrap={
      type = "method",
      args="()",
      returns = "CModuleThreadLoopWrap*",
      valuetype = "CModuleThreadLoopWrap"
    },
    getObjUID={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    setAllocable={
      type = "method",
      args="(IAllocatable*: allocator)",
      returns = "void",
      valuetype = "void"
    },
    setLoopThread={
      type = "method",
      args="(CModuleThreadLoop*: loopThread)",
      returns = "void",
      valuetype = "void"
    },
    freeArg={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    pushToQueue={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CSyncActiveQueue = {
  type = "class",
  inherits = "IAllocatable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSyncActiveQueue",
      valuetype = "CSyncActiveQueue",
    },
    setReadThreadID={
      type = "method",
      args="(unsigned long long: tid)",
      returns = "void",
      valuetype = "void"
    },
    calcWriteMsgNum={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    updateProfileData={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setProfileFlag={
      type = "method",
      args="(bool: flag)",
      returns = "void",
      valuetype = "void"
    },
    getTaskNum={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    flushWriteMsg={
      type = "method",
      args="(bool: flag)",
      returns = "void",
      valuetype = "void"
    },
    updateRead={
      type = "method",
      args="(unsigned int: diff)",
      returns = "void",
      valuetype = "void"
    },
    updateWrite={
      type = "method",
      args="(unsigned int: diff,bool: isAll)",
      returns = "void",
      valuetype = "void"
    },
    flushReadMsg={
      type = "method",
      args="(bool: flag)",
      returns = "void",
      valuetype = "void"
    },
    setWriteThreadID={
      type = "method",
      args="(unsigned long long: tid)",
      returns = "void",
      valuetype = "void"
    },
    setQueueName={
      type = "method",
      args="(string: queueName)",
      returns = "void",
      valuetype = "void"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    calcReadMsgNum={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    doProfile={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    cleanReadMsg={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CSyncActiveQueueWrap = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSyncActiveQueueWrap",
      valuetype = "CSyncActiveQueueWrap",
    },
    flushQueue={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setLoopThread={
      type = "method",
      args="(CModuleThreadLoop*: loopThread)",
      returns = "void",
      valuetype = "void"
    },
    setLoopThreadWrap={
      type = "method",
      args="(CModuleThreadLoopWrap*: loopThreadWrap)",
      returns = "void",
      valuetype = "void"
    },
    setCommunicationQ={
      type = "method",
      args="(CSyncActiveQueue*: inputQ,CSyncActiveQueue*: outputQ)",
      returns = "void",
      valuetype = "void"
    },
    update={
      type = "method",
      args="(unsigned int: diff)",
      returns = "void",
      valuetype = "void"
    },
    genUID={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    handleTask={
      type = "method",
      args="(int: diff)",
      returns = "void",
      valuetype = "void"
    },
    setThreadID={
      type = "method",
      args="(unsigned long long: tid)",
      returns = "void",
      valuetype = "void"
    },
    freeObj={
      type = "method",
      args="(CTask*: task)",
      returns = "void",
      valuetype = "void"
    },
    doProfile={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CIntervalTimer = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CIntervalTimer",
      valuetype = "CIntervalTimer",
    },
    reset={
      type = "method",
      args="(bool: force)",
      returns = "void",
      valuetype = "void"
    },
    getCurInterval={
      type = "method",
      args="()",
      returns = "long long",
      valuetype = "long long"
    },
    getRemainInterval={
      type = "method",
      args="()",
      returns = "long long",
      valuetype = "long long"
    },
    isValid={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    setMaxNum={
      type = "method",
      args="(unsigned int: num)",
      returns = "void",
      valuetype = "void"
    },
    update={
      type = "method",
      args="(long long: diff)",
      returns = "void",
      valuetype = "void"
    },
    isPassed={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      args="(unsigned int: maxInterval,unsigned int: num)",
      returns = "void",
      valuetype = "void"
    },
    onTimeout={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    doTimeout={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setMaxInterval={
      type = "method",
      args="(long long: maxInterval)",
      returns = "void",
      valuetype = "void"
    },
    getRemainSecs={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getMaxSecs={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
  },
},

CManualIntervalTimer = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CManualIntervalTimer",
      valuetype = "CManualIntervalTimer",
    },
    reset={
      type = "method",
      args="(bool: force)",
      returns = "void",
      valuetype = "void"
    },
    getCurInterval={
      type = "method",
      args="()",
      returns = "long long",
      valuetype = "long long"
    },
    getRemainInterval={
      type = "method",
      args="()",
      returns = "long long",
      valuetype = "long long"
    },
    update={
      type = "method",
      args="(long long: diff)",
      returns = "bool",
      valuetype = "bool"
    },
    isPassed={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      args="(unsigned int: maxInterval)",
      returns = "void",
      valuetype = "void"
    },
    setMaxInterval={
      type = "method",
      args="(long long: maxInterval)",
      returns = "void",
      valuetype = "void"
    },
    getRemainSecs={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getMaxSecs={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
  },
},

CIntervalTimerMgr = {
  type = "class",
  inherits = "CManualSingleton<GXMISC::CIntervalTimerMgr> ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CIntervalTimerMgr",
      valuetype = "CIntervalTimerMgr",
    },
    addTimer={
      type = "method",
      args="(CIntervalTimer*: timer,bool: isNeedFree)",
      returns = "void",
      valuetype = "void"
    },
    update={
      type = "method",
      args="(long long: diff)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CConfigMap = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CConfigMap",
      valuetype = "CConfigMap",
    },
    getConfigs={
      type = "method",
      args="()",
      returns = "map<basic_string<char>, map<basic_string<char>, basic_string<char>, less<basic_string<char> >, allocator<pair<const basic_string<char>, basic_string<char> > > >, less<basic_string<char> >, allocator<pair<const basic_string<char>, map<basic_string<char>, basic_string<char>, less<basic_string<char> >, allocator<pair<const basic_string<char>, basic_string<char> > > > > > >*",
      valuetype = "map<basic_string<char>, map<basic_string<char>, basic_string<char>, less<basic_string<char> >, allocator<pair<const basic_string<char>, basic_string<char> > > >, less<basic_string<char> >, allocator<pair<const basic_string<char>, map<basic_string<char>, basic_string<char>, less<basic_string<char> >, allocator<pair<const basic_string<char>, basic_string<char> > > > > > >"
    },
    readConfigValue={
      type = "method",
      args="(char*: section,char*: key)",
      returns = "int",
      valuetype = "int"
    },
    setConfigs={
      type = "method",
      args="(map<basic_string<char>, map<basic_string<char>, basic_string<char>, less<basic_string<char> >, allocator<pair<const basic_string<char>, basic_string<char> > > >, less<basic_string<char> >, allocator<pair<const basic_string<char>, map<basic_string<char>, basic_string<char>, less<basic_string<char> >, allocator<pair<const basic_string<char>, basic_string<char> > > > > > >*: configs)",
      returns = "void",
      valuetype = "void"
    },
    readConfigText={
      type = "method",
      args="(char*: section,char*: key)",
      returns = "string",
      valuetype = "string"
    },
  },
},

IModuleConfig = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IModuleConfig",
      valuetype = "IModuleConfig",
    },
    getFrameNumPerSecond={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    setModuleName={
      type = "method",
      args="(string: name)",
      returns = "void",
      valuetype = "void"
    },
    getCloseWaitSecsAllLoop={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getMaxUserNumPerLoop={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getModuleName={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    onLoadConfig={
      type = "method",
      args="(CConfigMap*: configs)",
      returns = "bool",
      valuetype = "bool"
    },
    getLoopThreadNum={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    check={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
  },
},

IModuleManager = {
  type = "class",
  inherits = "IStopHandler ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IModuleManager",
      valuetype = "IModuleManager",
    },
    setModuleName={
      type = "method",
      args="(string: name)",
      returns = "void",
      valuetype = "void"
    },
    start={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getModuleName={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    getModuleConfig={
      type = "method",
      args="()",
      returns = "IModuleConfig*",
      valuetype = "IModuleConfig"
    },
    onLoadConfig={
      type = "method",
      args="(CConfigMap*: configs)",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    loop={
      type = "method",
      args="(int: diff)",
      returns = "bool",
      valuetype = "bool"
    },
    onStat={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

IServiceModule = {
  type = "class",
  inherits = "IModuleManager ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IServiceModule",
      valuetype = "IServiceModule",
    },
    getCurrentLoopTime={
      type = "method",
      args="()",
      returns = "long long",
      valuetype = "long long"
    },
    start={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    isInitLoop={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getLastLoopTime={
      type = "method",
      args="()",
      returns = "long long",
      valuetype = "long long"
    },
    loop={
      type = "method",
      args="(int: diff)",
      returns = "bool",
      valuetype = "bool"
    },
  },
},

CModuleThreadLoop = {
  type = "class",
  inherits = "IRunnable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CModuleThreadLoop",
      valuetype = "CModuleThreadLoop",
    },
    getThreadLoopWrap={
      type = "method",
      args="()",
      returns = "CModuleThreadLoopWrap*",
      valuetype = "CModuleThreadLoopWrap"
    },
    run={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setLoopWrap={
      type = "method",
      args="(CModuleThreadLoopWrap*: loopWrap)",
      returns = "void",
      valuetype = "void"
    },
    freeTask={
      type = "method",
      args="(CTask*: arg)",
      returns = "void",
      valuetype = "void"
    },
    setFreeFlag={
      type = "method",
      args="(bool: flag)",
      returns = "void",
      valuetype = "void"
    },
    setCommunicationQ={
      type = "method",
      args="(CSyncActiveQueue*: inputQ,CSyncActiveQueue*: outputQ)",
      returns = "void",
      valuetype = "void"
    },
    getTaskQueueWrap={
      type = "method",
      args="()",
      returns = "CSyncActiveQueueWrap*",
      valuetype = "CSyncActiveQueueWrap"
    },
    start={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    needFree={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    setModuleConfig={
      type = "method",
      args="(IModuleConfig*: config)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CModuleThreadLoopWrap = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CModuleThreadLoopWrap",
      valuetype = "CModuleThreadLoopWrap",
    },
    isUserIndex={
      type = "method",
      args="(unsigned long long: uid)",
      returns = "bool",
      valuetype = "bool"
    },
    isMaxUserNum={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    isRunning={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    setTagId={
      type = "method",
      args="(unsigned char: tagId)",
      returns = "void",
      valuetype = "void"
    },
    freeTask={
      type = "method",
      args="(CTask*: arg)",
      returns = "void",
      valuetype = "void"
    },
    setService={
      type = "method",
      args="(GxService*: service)",
      returns = "void",
      valuetype = "void"
    },
    stop={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    getTaskQueueWrap={
      type = "method",
      args="()",
      returns = "CSyncActiveQueueWrap*",
      valuetype = "CSyncActiveQueueWrap"
    },
    getService={
      type = "method",
      args="()",
      returns = "GxService*",
      valuetype = "GxService"
    },
    breath={
      type = "method",
      args="(int: diff)",
      returns = "void",
      valuetype = "void"
    },
    start={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    getMaxUserNum={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getModuleThreadLoop={
      type = "method",
      args="()",
      returns = "CModuleThreadLoop*",
      valuetype = "CModuleThreadLoop"
    },
    isExitRun={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    genUniqueIndex={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    getUserNum={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getTagId={
      type = "method",
      args="()",
      returns = "unsigned char",
      valuetype = "unsigned char"
    },
    getOutputQSize={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
  },
},

CSimpleThreadLoopWrap = {
  type = "class",
  inherits = "CModuleThreadLoopWrap ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSimpleThreadLoopWrap",
      valuetype = "CSimpleThreadLoopWrap",
    },
  },
},

CModuleBase = {
  type = "class",
  inherits = "IModuleManager ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CModuleBase",
      valuetype = "CModuleBase",
    },
    checkAllLoopStop={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getMaxConnNum={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    setService={
      type = "method",
      args="(GxService*: service)",
      returns = "void",
      valuetype = "void"
    },
    getLeastLoop={
      type = "method",
      args="()",
      returns = "CModuleThreadLoopWrap*",
      valuetype = "CModuleThreadLoopWrap"
    },
    getService={
      type = "method",
      args="()",
      returns = "GxService*",
      valuetype = "GxService"
    },
    start={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    getLoopNum={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    onStop={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CLoopToThreadTask = {
  type = "class",
  inherits = "CTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CLoopToThreadTask",
      valuetype = "CLoopToThreadTask",
    },
  },
},

CThreadToLoopTask = {
  type = "class",
  inherits = "CTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CThreadToLoopTask",
      valuetype = "CThreadToLoopTask",
    },
    isSuccess={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getErrorCode={
      type = "method",
      args="()",
      returns = "short",
      valuetype = "short"
    },
    setSuccess={
      type = "method",
      args="(short: flag)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CDbConnTask = {
  type = "class",
  inherits = "CThreadToLoopTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CDbConnTask",
      valuetype = "CDbConnTask",
    },
    getDbUserIndex={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    getDbConnWrap={
      type = "method",
      args="()",
      returns = "CDatabaseConnWrap*",
      valuetype = "CDatabaseConnWrap"
    },
    setDbUserIndex={
      type = "method",
      args="(unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CDbWrapTask = {
  type = "class",
  inherits = "CLoopToThreadTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CDbWrapTask",
      valuetype = "CDbWrapTask",
    },
    setDbUserIndex={
      type = "method",
      args="(unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
    getDbUserIndex={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    getDbConn={
      type = "method",
      args="()",
      returns = "CDatabaseConn*",
      valuetype = "CDatabaseConn"
    },
    doRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CDbTaskConnected = {
  type = "class",
  inherits = "CDbConnTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CDbTaskConnected",
      valuetype = "CDbTaskConnected",
    },
    doRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CDbTaskClose = {
  type = "class",
  inherits = "CDbConnTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CDbTaskClose",
      valuetype = "CDbTaskClose",
    },
    doRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CDatabaseConn = {
  type = "class",
  inherits = "CModuleThreadLoop ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CDatabaseConn",
      valuetype = "CDatabaseConn",
    },
    stopMsgHandle={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setDbUrlInfo={
      type = "method",
      args="(string: dbHost,string: dbName,string: dbUser,string: dbPass)",
      returns = "void",
      valuetype = "void"
    },
    setStartParam={
      type = "method",
      args="(unsigned int: reconnInterval)",
      returns = "void",
      valuetype = "void"
    },
    onConntected={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    pushTask={
      type = "method",
      args="(CDbConnTask*: task,unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
    onClose={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    isDelUser={
      type = "method",
      args="(unsigned long long: uid)",
      returns = "bool",
      valuetype = "bool"
    },
    ping={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    isEmptyConn={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    start={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    toString={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    reconnect={
      type = "method",
      args="(unsigned int: num)",
      returns = "bool",
      valuetype = "bool"
    },
    pushDelUser={
      type = "method",
      args="(unsigned long long: uid)",
      returns = "void",
      valuetype = "void"
    },
    isStopMsgHandle={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    isActive={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
  },
},

CDatabaseConnWrap = {
  type = "class",
  inherits = "CSimpleThreadLoopWrap ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CDatabaseConnWrap",
      valuetype = "CDatabaseConnWrap",
    },
    findUser={
      type = "method",
      args="(unsigned long long: index)",
      returns = "CDatabaseHandler*",
      valuetype = "CDatabaseHandler"
    },
    setDbUrlInfo={
      type = "method",
      args="(string: dbHost,string: dbName,string: dbUser,string: dbPass)",
      returns = "void",
      valuetype = "void"
    },
    setStartParam={
      type = "method",
      args="(unsigned int: reconnInterval)",
      returns = "void",
      valuetype = "void"
    },
    getDbConn={
      type = "method",
      args="()",
      returns = "CDatabaseConn*",
      valuetype = "CDatabaseConn"
    },
    isStop={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    addUser={
      type = "method",
      args="(unsigned long long: index,CDatabaseHandler*: handler)",
      returns = "void",
      valuetype = "void"
    },
    pushTask={
      type = "method",
      args="(CDbWrapTask*: task)",
      returns = "void",
      valuetype = "void"
    },
    setDbHostParam={
      type = "method",
      args="(CDbHostParam*: dbParam)",
      returns = "void",
      valuetype = "void"
    },
    getDbConnMgr={
      type = "method",
      args="()",
      returns = "CDatabaseConnMgr*",
      valuetype = "CDatabaseConnMgr"
    },
    onConnected={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    getDbHostID={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    start={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    removeUser={
      type = "method",
      args="(unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
    toString={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    setDbHostID={
      type = "method",
      args="(unsigned int: id)",
      returns = "void",
      valuetype = "void"
    },
    setTag={
      type = "method",
      args="(unsigned char: tag)",
      returns = "void",
      valuetype = "void"
    },
    getTag={
      type = "method",
      args="()",
      returns = "unsigned char",
      valuetype = "unsigned char"
    },
    onClose={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    isActive={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    handleClearAllUser={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

IScriptObject = {
  type = "class",
  inherits = "IFreeable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IScriptObject",
      valuetype = "IScriptObject",
    },
    getScriptHandleClassName={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    getScriptObject={
      type = "method",
      args="()",
      returns = "s_object",
      valuetype = "s_object"
    },
    sCall={
      type = "method",
      args="(char*: functionName)",
      returns = "string",
      valuetype = "string"
    },
    setScriptHandleClassName={
      type = "method",
      args="(string: newObjectFuncName)",
      returns = "void",
      valuetype = "void"
    },
    isExistMember={
      type = "method",
      args="(char*: functionName)",
      returns = "bool",
      valuetype = "bool"
    },
    vCall={
      type = "method",
      args="(char*: functionName)",
      returns = "void",
      valuetype = "void"
    },
    bCall={
      type = "method",
      args="(char*: functionName)",
      returns = "bool",
      valuetype = "bool"
    },
  },
},

IHandler = {
  type = "class",
  inherits = "IScriptObject ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IHandler",
      valuetype = "IHandler",
    },
    reset={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    onDelete={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setParam={
      type = "method",
      args="(IAllocatable*: allocable,unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
    handle={
      type = "method",
      args="(char*: msg,unsigned int: len)",
      returns = "EHandleRet",
      valuetype = "EHandleRet"
    },
    setStarted={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    isValid={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getName={
      type = "method",
      args="()",
      returns = "char*",
      valuetype = "char"
    },
    onReconnect={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    isStarted={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getUniqueIndex={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    breath={
      type = "method",
      args="(int: diff)",
      returns = "void",
      valuetype = "void"
    },
    start={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    close={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CDatabaseHandler = {
  type = "class",
  inherits = "IHandler ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CDatabaseHandler",
      valuetype = "CDatabaseHandler",
    },
    handle={
      type = "method",
      args="(char*: msg,unsigned int: len)",
      returns = "EHandleRet",
      valuetype = "EHandleRet"
    },
    freeDatabaseTask={
      type = "method",
      args="(CDbWrapTask*: task)",
      returns = "void",
      valuetype = "void"
    },
    getDbWrap={
      type = "method",
      args="()",
      returns = "CDatabaseConnWrap*",
      valuetype = "CDatabaseConnWrap"
    },
    isValid={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    pushTask={
      type = "method",
      args="(CDbWrapTask*: task)",
      returns = "void",
      valuetype = "void"
    },
    getTag={
      type = "method",
      args="()",
      returns = "unsigned char",
      valuetype = "unsigned char"
    },
    kick={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CDbHostParam = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CDbHostParam",
      valuetype = "CDbHostParam",
    },
  },
},

CDatabaseConfig = {
  type = "class",
  inherits = "IModuleConfig ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CDatabaseConfig",
      valuetype = "CDatabaseConfig",
    },
    setCleanupParm={
      type = "method",
      args="(int: reconnInterval)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CDatabaseConnMgr = {
  type = "class",
  inherits = "CModuleBase ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CDatabaseConnMgr",
      valuetype = "CDatabaseConnMgr",
    },
    pushTask={
      type = "method",
      args="(CDbWrapTask*: task,unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
    getUser={
      type = "method",
      args="(unsigned long long: index)",
      returns = "CDatabaseHandler*",
      valuetype = "CDatabaseHandler"
    },
    removeUser={
      type = "method",
      args="(unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
    getConfig={
      type = "method",
      args="()",
      returns = "CDatabaseConfig*",
      valuetype = "CDatabaseConfig"
    },
    size={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},

CGameTime = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CGameTime",
      valuetype = "CGameTime",
    },
    setGameTime={
      type = "method",
      args="(unsigned int: val)",
      returns = "void",
      valuetype = "void"
    },
    toString={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    getGameTime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},

CMemInStream = {
  type = "class",
  inherits = "IUnStream ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CMemInStream",
      valuetype = "CMemInStream",
    },
    reset={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    getFreeSize={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    maxSize={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    curData={
      type = "method",
      args="()",
      returns = "char*",
      valuetype = "char"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    data={
      type = "method",
      args="()",
      returns = "char*",
      valuetype = "char"
    },
    size={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},

CMemOutStream = {
  type = "class",
  inherits = "IStream ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CMemOutStream",
      valuetype = "CMemOutStream",
    },
    reset={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    getFreeSize={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    maxSize={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    curData={
      type = "method",
      args="()",
      returns = "char*",
      valuetype = "char"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    data={
      type = "method",
      args="()",
      returns = "char*",
      valuetype = "char"
    },
    size={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},

CMemOutputStream = {
  type = "class",
  inherits = "CMemOutStream ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CMemOutputStream",
      valuetype = "CMemOutputStream",
    },
    writeInt8={
      type = "method",
      args="(char: val)",
      returns = "char",
      valuetype = "char"
    },
    writeUInt64ByPos={
      type = "method",
      args="(unsigned long long: val,int: pos)",
      returns = "char",
      valuetype = "char"
    },
    writeUInt64={
      type = "method",
      args="(unsigned long long: val)",
      returns = "char",
      valuetype = "char"
    },
    writeString={
      type = "method",
      args="(CScriptString: str)",
      returns = "short",
      valuetype = "short"
    },
    writeUInt16ByPos={
      type = "method",
      args="(unsigned short: val,int: pos)",
      returns = "char",
      valuetype = "char"
    },
    writeUInt16={
      type = "method",
      args="(unsigned short: val)",
      returns = "char",
      valuetype = "char"
    },
    writeInt64={
      type = "method",
      args="(long long: val)",
      returns = "char",
      valuetype = "char"
    },
    writeUInt8={
      type = "method",
      args="(unsigned char: val)",
      returns = "char",
      valuetype = "char"
    },
    writeInt32={
      type = "method",
      args="(int: val)",
      returns = "char",
      valuetype = "char"
    },
    getCurrentPos={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    writeUInt8ByPos={
      type = "method",
      args="(unsigned char: val,int: pos)",
      returns = "char",
      valuetype = "char"
    },
    writeUInt32ByPos={
      type = "method",
      args="(unsigned int: val,int: pos)",
      returns = "char",
      valuetype = "char"
    },
    writeBufferByPos={
      type = "method",
      args="(char*: buf,unsigned int: len,unsigned int: pos)",
      returns = "bool",
      valuetype = "bool"
    },
    writeSString={
      type = "method",
      args="(CScriptString: str)",
      returns = "short",
      valuetype = "short"
    },
    writeUInt32={
      type = "method",
      args="(unsigned int: val)",
      returns = "char",
      valuetype = "char"
    },
    writeInt16={
      type = "method",
      args="(short: val)",
      returns = "char",
      valuetype = "char"
    },
  },
},

CMemInputStream = {
  type = "class",
  inherits = "CMemInStream ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CMemInputStream",
      valuetype = "CMemInputStream",
    },
    readUInt64={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    readInt32={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    peakUInt16={
      type = "method",
      args="(int: skipPos)",
      returns = "unsigned short",
      valuetype = "unsigned short"
    },
    readSString={
      type = "method",
      args="()",
      returns = "CScriptString",
      valuetype = "CScriptString"
    },
    peakUInt64={
      type = "method",
      args="(int: skipPos)",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    peakUInt8={
      type = "method",
      args="(int: skipPos)",
      returns = "unsigned char",
      valuetype = "unsigned char"
    },
    readInt16={
      type = "method",
      args="()",
      returns = "short",
      valuetype = "short"
    },
    readInt64={
      type = "method",
      args="()",
      returns = "long long",
      valuetype = "long long"
    },
    readUInt8={
      type = "method",
      args="()",
      returns = "unsigned char",
      valuetype = "unsigned char"
    },
    readString={
      type = "method",
      args="()",
      returns = "CScriptString",
      valuetype = "CScriptString"
    },
    readUInt32={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    peakBuffer={
      type = "method",
      args="(char*: buff,unsigned int: len,unsigned int: skipPos)",
      returns = "bool",
      valuetype = "bool"
    },
    readUInt16={
      type = "method",
      args="()",
      returns = "unsigned short",
      valuetype = "unsigned short"
    },
    readInt8={
      type = "method",
      args="()",
      returns = "char",
      valuetype = "char"
    },
    peakUInt32={
      type = "method",
      args="(int: skipPos)",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},

dbColProxy = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "dbColProxy",
      valuetype = "dbColProxy",
    },
  },
},

TDBStructBase = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "TDBStructBase",
      valuetype = "TDBStructBase",
    },
  },
},

CIni = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CIni",
      valuetype = "CIni",
    },
    findIndex={
      type = "method",
      args="(char*: )",
      returns = "int",
      valuetype = "int"
    },
    getData={
      type = "method",
      args="()",
      returns = "char*",
      valuetype = "char"
    },
    getContinueDataNum={
      type = "method",
      args="(char*: section)",
      returns = "int",
      valuetype = "int"
    },
    readCaption={
      type = "method",
      args="(char*: section,int: lines,char*: str,int: size)",
      returns = "char*",
      valuetype = "char"
    },
    returnLineNum={
      type = "method",
      args="(char*: )",
      returns = "int",
      valuetype = "int"
    },
    close={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    findOneLine={
      type = "method",
      args="(int: )",
      returns = "int",
      valuetype = "int"
    },
    save={
      type = "method",
      args="(char*: filename)",
      returns = "bool",
      valuetype = "bool"
    },
    readOneLine={
      type = "method",
      args="(int: )",
      returns = "char*",
      valuetype = "char"
    },
    readIntIfExist={
      type = "method",
      args="(char*: section,char*: key,int: nResult)",
      returns = "bool",
      valuetype = "bool"
    },
  },
},

IniItem = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "IniItem",
      valuetype = "IniItem",
    },
  },
},

CIniSection = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CIniSection",
      valuetype = "CIniSection",
    },
  },
},

CLibConfig = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CLibConfig",
      valuetype = "CLibConfig",
    },
    getStatInterval={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    init={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setConfig={
      type = "method",
      args="(ELibConfig: config,unsigned int: flag)",
      returns = "void",
      valuetype = "void"
    },
    getStatDb={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    getConfig={
      type = "method",
      args="(ELibConfig: config)",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    isConfig={
      type = "method",
      args="(ELibConfig: config)",
      returns = "bool",
      valuetype = "bool"
    },
  },
},

SSocketLoopEventArg = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "SSocketLoopEventArg",
      valuetype = "SSocketLoopEventArg",
    },
  },
},

SMainLoopEventArg = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "SMainLoopEventArg",
      valuetype = "SMainLoopEventArg",
    },
  },
},

CSocketInputStream = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSocketInputStream",
      valuetype = "CSocketInputStream",
    },
    peakUint={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    peakUint16={
      type = "method",
      args="()",
      returns = "unsigned short",
      valuetype = "unsigned short"
    },
    getBuffer={
      type = "method",
      args="()",
      returns = "char*",
      valuetype = "char"
    },
    capacity={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getTailPos={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    peek={
      type = "method",
      args="(char*: buf,int: len)",
      returns = "bool",
      valuetype = "bool"
    },
    read={
      type = "method",
      args="(char*: buf,int: len)",
      returns = "int",
      valuetype = "int"
    },
    skip={
      type = "method",
      args="(int: len)",
      returns = "bool",
      valuetype = "bool"
    },
    peakByte={
      type = "method",
      args="()",
      returns = "char",
      valuetype = "char"
    },
    initsize={
      type = "method",
      args="(CSocket*: sock,int: BufferLen,int: MaxBufferLen)",
      returns = "void",
      valuetype = "void"
    },
    length={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    peakInt={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    isEmpty={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getBuffLen={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getHeadPos={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    peakInt16={
      type = "method",
      args="()",
      returns = "short",
      valuetype = "short"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    size={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    resize={
      type = "method",
      args="(int: size)",
      returns = "bool",
      valuetype = "bool"
    },
    fill={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
  },
},

CSocketOutputStream = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSocketOutputStream",
      valuetype = "CSocketOutputStream",
    },
    capacity={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getTailPos={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    write={
      type = "method",
      args="(char*: buf,int: len)",
      returns = "int",
      valuetype = "int"
    },
    initsize={
      type = "method",
      args="(CSocket*: sock,int: BufferSize,int: MaxBufferSize)",
      returns = "void",
      valuetype = "void"
    },
    length={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    isEmpty={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getBuffLen={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getHeadPos={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    flush={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getBuffer={
      type = "method",
      args="()",
      returns = "char*",
      valuetype = "char"
    },
    getTail={
      type = "method",
      args="()",
      returns = "char*",
      valuetype = "char"
    },
    resize={
      type = "method",
      args="(int: size)",
      returns = "bool",
      valuetype = "bool"
    },
    size={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
  },
},

CPackHandleAry = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CPackHandleAry",
      valuetype = "CPackHandleAry",
    },
    getPack={
      type = "method",
      args="(int: index)",
      returns = "char*",
      valuetype = "char"
    },
    push={
      type = "method",
      args="(char*: msg,int: len)",
      returns = "void",
      valuetype = "void"
    },
    getPackNum={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
  },
},

ISocketPacketHandler = {
  type = "class",
  inherits = "IFreeable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "ISocketPacketHandler",
      valuetype = "ISocketPacketHandler",
    },
    needHandle={
      type = "method",
      args="(EPackOpt: opt)",
      returns = "bool",
      valuetype = "bool"
    },
    isVarPacket={
      type = "method",
      args="(char*: buff,int: len)",
      returns = "bool",
      valuetype = "bool"
    },
    sendPack={
      type = "method",
      args="(char*: msg,unsigned int: len)",
      returns = "void",
      valuetype = "void"
    },
    onSendPack={
      type = "method",
      args="(char*: buff,int: len,bool: singalFlag)",
      returns = "void",
      valuetype = "void"
    },
    onBeforeFlushToSocket={
      type = "method",
      args="(char*: buff,int: len,char*: outBuff,int: outLen)",
      returns = "int",
      valuetype = "int"
    },
    setSocket={
      type = "method",
      args="(CSocket*: socket)",
      returns = "void",
      valuetype = "void"
    },
    getUnpacketNum={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    onHandleVarUnpacket={
      type = "method",
      args="(char*: buff,char*: varBuff,int: len)",
      returns = "void",
      valuetype = "void"
    },
    onAfterReadFromSocket={
      type = "method",
      args="(char*: buff,int: len,char*: outBuff,int: outLen)",
      returns = "int",
      valuetype = "int"
    },
    setUnpacketNum={
      type = "method",
      args="(int: unpacketNum)",
      returns = "void",
      valuetype = "void"
    },
    getMaxVarPackLen={
      type = "method",
      args="(char*: buff)",
      returns = "int",
      valuetype = "int"
    },
    canUnpacket={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getPackHeaderLen={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getSocket={
      type = "method",
      args="()",
      returns = "CSocket*",
      valuetype = "CSocket"
    },
    onPackAfterFromSocket={
      type = "method",
      args="(char*: buff,int: len,char*: outBuff,int: outLen)",
      returns = "int",
      valuetype = "int"
    },
    canReadPack={
      type = "method",
      args="(char*: buff,int: len)",
      returns = "int",
      valuetype = "int"
    },
    onPackBeforeFlushToSocket={
      type = "method",
      args="(char*: buff,int: len,char*: outBuff,int: outLen)",
      returns = "int",
      valuetype = "int"
    },
    unpacket={
      type = "method",
      args="(CNetSocketLoopTask*: task,char*: packBuff,int: packBuffLen,char*: packBuffTempRead,int: packBuffTempReadLen)",
      returns = "bool",
      valuetype = "bool"
    },
    onRecvPack={
      type = "method",
      args="(char*: buff,int: len,bool: singalFlag)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CEmptyPacketHandler = {
  type = "class",
  inherits = "ISocketPacketHandler ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CEmptyPacketHandler",
      valuetype = "CEmptyPacketHandler",
    },
    unpacket={
      type = "method",
      args="(CNetSocketLoopTask*: task,char*: packBuff,int: packBuffLen,char*: packBuffTempRead,int: packBuffTempReadLen)",
      returns = "bool",
      valuetype = "bool"
    },
    canUnpacket={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getPackHeaderLen={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
  },
},

CDefaultPacketHandler = {
  type = "class",
  inherits = "ISocketPacketHandler ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CDefaultPacketHandler",
      valuetype = "CDefaultPacketHandler",
    },
    unpacket={
      type = "method",
      args="(CNetSocketLoopTask*: task,char*: packBuff,int: packBuffLen,char*: packBuffTempRead,int: packBuffTempReadLen)",
      returns = "bool",
      valuetype = "bool"
    },
    canUnpacket={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getPackHeaderLen={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
  },
},

CSocket = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSocket",
      valuetype = "CSocket",
    },
    setWaitCloseSecs={
      type = "method",
      args="(unsigned int: secs)",
      returns = "void",
      valuetype = "void"
    },
    getSocket={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    setSocketEventLoop={
      type = "method",
      args="(CSocketEventLoop*: loop)",
      returns = "void",
      valuetype = "void"
    },
    getOutputStream={
      type = "method",
      args="()",
      returns = "CSocketOutputStream*",
      valuetype = "CSocketOutputStream"
    },
    getUniqueIndex={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    getReceiveBufferSize={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getUnpacketNum={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    cleanUp={
      type = "method",
      args="(CSocketEventLoop*: loop)",
      returns = "void",
      valuetype = "void"
    },
    getInputLen={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getPacketHandler={
      type = "method",
      args="()",
      returns = "ISocketPacketHandler*",
      valuetype = "ISocketPacketHandler"
    },
    close={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setLinger={
      type = "method",
      args="(int: lingertime)",
      returns = "bool",
      valuetype = "bool"
    },
    isNonBlocking={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getThreadID={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    create={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    setPacketHandler={
      type = "method",
      args="(ISocketPacketHandler*: handler)",
      returns = "void",
      valuetype = "void"
    },
    setReceiveBufferSize={
      type = "method",
      args="(int: size)",
      returns = "bool",
      valuetype = "bool"
    },
    setReuseAddr={
      type = "method",
      args="(bool: on)",
      returns = "bool",
      valuetype = "bool"
    },
    write={
      type = "method",
      args="(char*: msg,int: len)",
      returns = "int",
      valuetype = "int"
    },
    setUniqueIndex={
      type = "method",
      args="(unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
    isReuseAddr={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    toString={
      type = "method",
      args="()",
      returns = "char*",
      valuetype = "char"
    },
    onRead={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getSendBufferSize={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    isSockError={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getOutputLen={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getPort={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getLinger={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    available={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    isNeedWrite={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    read={
      type = "method",
      args="(char*: msg,int: len)",
      returns = "int",
      valuetype = "int"
    },
    isValid={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    setSocket={
      type = "method",
      args="(int: id)",
      returns = "void",
      valuetype = "void"
    },
    setActive={
      type = "method",
      args="(bool: flag)",
      returns = "void",
      valuetype = "void"
    },
    getSockError={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    setSendBufferSize={
      type = "method",
      args="(int: size)",
      returns = "bool",
      valuetype = "bool"
    },
    needDel={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    onWrite={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getRemotePort={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getWaitCloseSecs={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    getInputStream={
      type = "method",
      args="()",
      returns = "CSocketInputStream*",
      valuetype = "CSocketInputStream"
    },
    reset={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setNonBlocking={
      type = "method",
      args="(bool: on)",
      returns = "bool",
      valuetype = "bool"
    },
    getSocketEventLoop={
      type = "method",
      args="()",
      returns = "CSocketEventLoop*",
      valuetype = "CSocketEventLoop"
    },
    isActive={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    canUnpacket={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    unpacket={
      type = "method",
      args="(CNetSocketLoopTask*: task,char*: packBuff,int: packBuffLen,char*: packBuffTempRead,int: packBuffTempReadLen)",
      returns = "bool",
      valuetype = "bool"
    },
  },
},

CNetSocketLoopTask = {
  type = "class",
  inherits = "CThreadToLoopTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CNetSocketLoopTask",
      valuetype = "CNetSocketLoopTask",
    },
    getNetLoopWrap={
      type = "method",
      args="()",
      returns = "CNetLoopWrap*",
      valuetype = "CNetLoopWrap"
    },
    setSocketIndex={
      type = "method",
      args="(unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
    getSocketIndex={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
  },
},

CNetSocketLoopWrapTask = {
  type = "class",
  inherits = "CLoopToThreadTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CNetSocketLoopWrapTask",
      valuetype = "CNetSocketLoopWrapTask",
    },
    setSocketIndex={
      type = "method",
      args="(unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
    getSocketLoop={
      type = "method",
      args="()",
      returns = "CSocketEventLoop*",
      valuetype = "CSocketEventLoop"
    },
    getSocketIndex={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
  },
},

CNetSendPacketTask = {
  type = "class",
  inherits = "CNetSocketLoopWrapTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CNetSendPacketTask",
      valuetype = "CNetSendPacketTask",
    },
    getName={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    doRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    type={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},

CNetRecvPacketTask = {
  type = "class",
  inherits = "CNetSocketLoopTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CNetRecvPacketTask",
      valuetype = "CNetRecvPacketTask",
    },
    getName={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    doRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CNetWrapBroadCastTask = {
  type = "class",
  inherits = "CNetSocketLoopWrapTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CNetWrapBroadCastTask",
      valuetype = "CNetWrapBroadCastTask",
    },
    doRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CBroadcastPacketTask = {
  type = "class",
  inherits = "CNetSocketLoopWrapTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CBroadcastPacketTask",
      valuetype = "CBroadcastPacketTask",
    },
    doRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CNetSocketClose = {
  type = "class",
  inherits = "CNetSocketLoopTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CNetSocketClose",
      valuetype = "CNetSocketClose",
    },
    doRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CNetSocketDelTask = {
  type = "class",
  inherits = "CNetSocketLoopWrapTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CNetSocketDelTask",
      valuetype = "CNetSocketDelTask",
    },
    doRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CNetSocketAddRet = {
  type = "class",
  inherits = "CNetSocketLoopTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CNetSocketAddRet",
      valuetype = "CNetSocketAddRet",
    },
    doRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CSocketEventLoop = {
  type = "class",
  inherits = "CModuleThreadLoop ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSocketEventLoop",
      valuetype = "CSocketEventLoop",
    },
    stopMsgHandle={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setMsgPerFrame={
      type = "method",
      args="(unsigned int: msgPerFrame)",
      returns = "void",
      valuetype = "void"
    },
    pushTask={
      type = "method",
      args="(CNetSocketLoopTask*: task,unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
    setBroadCastQ={
      type = "method",
      args="(CSyncActiveQueue*: inputQ,CSyncActiveQueue*: outputQ)",
      returns = "void",
      valuetype = "void"
    },
    handleDelSocket={
      type = "method",
      args="(unsigned long long: index,int: waitCloseSecs,int: noDataNeedDel)",
      returns = "void",
      valuetype = "void"
    },
    init={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    isStopMsgHandle={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    handleWriteMsg={
      type = "method",
      args="(unsigned long long: index,char*: msg,unsigned int: len)",
      returns = "void",
      valuetype = "void"
    },
    getBroadcastQWrap={
      type = "method",
      args="()",
      returns = "CSyncActiveQueueWrap*",
      valuetype = "CSyncActiveQueueWrap"
    },
  },
},

CNetLoopWrap = {
  type = "class",
  inherits = "CSimpleThreadLoopWrap ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CNetLoopWrap",
      valuetype = "CNetLoopWrap",
    },
    writeMsg={
      type = "method",
      args="(char*: msg,int: len,unsigned long long: index,char*: name)",
      returns = "void",
      valuetype = "void"
    },
    handlePacket={
      type = "method",
      args="(unsigned long long: index,char*: msg,int: len)",
      returns = "void",
      valuetype = "void"
    },
    getNetConfig={
      type = "method",
      args="()",
      returns = "CNetModuleConfig*",
      valuetype = "CNetModuleConfig"
    },
    getSocketEventLoop={
      type = "method",
      args="()",
      returns = "CSocketEventLoop*",
      valuetype = "CSocketEventLoop"
    },
    delSocket={
      type = "method",
      args="(unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
    addSocket={
      type = "method",
      args="(CSocket*: socket,CSocketHandler*: handler)",
      returns = "void",
      valuetype = "void"
    },
    pushTask={
      type = "method",
      args="(CNetSocketLoopWrapTask*: task,unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
    getSocketHandlerAll={
      type = "method",
      args="(unsigned long long: index)",
      returns = "CSocketHandler*",
      valuetype = "CSocketHandler"
    },
    getUserNum={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getNetLoopWrapMgr={
      type = "method",
      args="()",
      returns = "CNetModule*",
      valuetype = "CNetModule"
    },
    handleCloseSocket={
      type = "method",
      args="(unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
    getSocketHandler={
      type = "method",
      args="(unsigned long long: index)",
      returns = "CSocketHandler*",
      valuetype = "CSocketHandler"
    },
    initBroadcastQ={
      type = "method",
      args="(CSyncActiveQueue*: loopInputQ,CSyncActiveQueue*: loopOutputQ)",
      returns = "void",
      valuetype = "void"
    },
    handleAddSocketRet={
      type = "method",
      args="(unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
    closeSocket={
      type = "method",
      args="(unsigned long long: index,int: waitSecs)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CSocketHandler = {
  type = "class",
  inherits = "IHandler ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSocketHandler",
      valuetype = "CSocketHandler",
    },
    getString={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    flush={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setRemoteAddr={
      type = "method",
      args="(string: ip,int: port)",
      returns = "void",
      valuetype = "void"
    },
    getLocalPort={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getNetLoopWrap={
      type = "method",
      args="()",
      returns = "CNetLoopWrap*",
      valuetype = "CNetLoopWrap"
    },
    setAddr={
      type = "method",
      args="(string: ip,int: port)",
      returns = "void",
      valuetype = "void"
    },
    getBufferStream={
      type = "method",
      args="()",
      returns = "CMemOutputStream*",
      valuetype = "CMemOutputStream"
    },
    send={
      type = "method",
      args="(char*: msg,int: len,char*: name)",
      returns = "void",
      valuetype = "void"
    },
    breath={
      type = "method",
      args="(int: )",
      returns = "void",
      valuetype = "void"
    },
    init={
      type = "method",
      args="(CNetLoopWrap*: loopWrap,unsigned long long: index)",
      returns = "void",
      valuetype = "void"
    },
    kick={
      type = "method",
      args="(int: secs)",
      returns = "void",
      valuetype = "void"
    },
    onFlushData={
      type = "method",
      args="(char*: msg,int: len)",
      returns = "bool",
      valuetype = "bool"
    },
    isScriptHandler={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getRemoteIp={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    getOtherHandler={
      type = "method",
      args="(unsigned long long: socketIndex)",
      returns = "CSocketHandler*",
      valuetype = "CSocketHandler"
    },
    isValid={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getSocketIndex={
      type = "method",
      args="()",
      returns = "unsigned long long",
      valuetype = "unsigned long long"
    },
    getLocalIp={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    getWaitSecs={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getRemotePort={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    reset={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    onDelete={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CScriptSocketHandler = {
  type = "class",
  inherits = "CSocketHandler ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CScriptSocketHandler",
      valuetype = "CScriptSocketHandler",
    },
    isScriptHandler={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    initScriptObject={
      type = "method",
      args="(CLuaVM*: scriptEngine)",
      returns = "bool",
      valuetype = "bool"
    },
    handle={
      type = "method",
      args="(char*: msg,unsigned int: len)",
      returns = "EHandleRet",
      valuetype = "EHandleRet"
    },
    start={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    close={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CSocketConnector = {
  type = "class",
  inherits = "CSocket ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSocketConnector",
      valuetype = "CSocketConnector",
    },
    reconnect={
      type = "method",
      args="(char*: host,unsigned short: port,unsigned int: diff)",
      returns = "bool",
      valuetype = "bool"
    },
    updateLastConnectTime={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    getReconnectDiff={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    setServerIP={
      type = "method",
      args="(string: val)",
      returns = "void",
      valuetype = "void"
    },
    getConnectDiff={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    setServerPort={
      type = "method",
      args="(unsigned short: val)",
      returns = "void",
      valuetype = "void"
    },
    toString={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    connect={
      type = "method",
      args="(char*: host,unsigned short: port,unsigned int: diff)",
      returns = "bool",
      valuetype = "bool"
    },
    setReconnectDiff={
      type = "method",
      args="(int: diff)",
      returns = "void",
      valuetype = "void"
    },
    setConnectDiff={
      type = "method",
      args="(int: val)",
      returns = "void",
      valuetype = "void"
    },
    getServerIP={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    canReconnect={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getServerPort={
      type = "method",
      args="()",
      returns = "unsigned short",
      valuetype = "unsigned short"
    },
  },
},

CSocketListener = {
  type = "class",
  inherits = "CSocket ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSocketListener",
      valuetype = "CSocketListener",
    },
    getBacklog={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    accept={
      type = "method",
      args="()",
      returns = "CSocket*",
      valuetype = "CSocket"
    },
    start={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
  },
},

CSocketBroadCast = {
  type = "class",
  inherits = "CModuleThreadLoop ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSocketBroadCast",
      valuetype = "CSocketBroadCast",
    },
    init={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CNetBroadcastWrap = {
  type = "class",
  inherits = "CSimpleThreadLoopWrap ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CNetBroadcastWrap",
      valuetype = "CNetBroadcastWrap",
    },
  },
},

CNetBroadcastModule = {
  type = "class",
  inherits = "CModuleBase ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CNetBroadcastModule",
      valuetype = "CNetBroadcastModule",
    },
  },
},

CServerTaskPool = {
  type = "class",
  inherits = "CModuleThreadLoop ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CServerTaskPool",
      valuetype = "CServerTaskPool",
    },
    newScriptRetTask={
      type = "method",
      args="(string: functionName)",
      returns = "CServerScriptRetTask*",
      valuetype = "CServerScriptRetTask"
    },
    getScriptEngine={
      type = "method",
      args="()",
      returns = "CLuaVM*",
      valuetype = "CLuaVM"
    },
    init={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    initBeforeRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CServerPoolTask = {
  type = "class",
  inherits = "CThreadToLoopTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CServerPoolTask",
      valuetype = "CServerPoolTask",
    },
    getTaskPoolWrap={
      type = "method",
      args="()",
      returns = "CServerTaskPoolWrap*",
      valuetype = "CServerTaskPoolWrap"
    },
    setDebugInfo={
      type = "method",
      args="(string: str)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CServerPoolWrapTask = {
  type = "class",
  inherits = "CLoopToThreadTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CServerPoolWrapTask",
      valuetype = "CServerPoolWrapTask",
    },
    getServerTaskPool={
      type = "method",
      args="()",
      returns = "CServerTaskPool*",
      valuetype = "CServerTaskPool"
    },
    setDebugInfo={
      type = "method",
      args="(string: str)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CSocketReconnectTask = {
  type = "class",
  inherits = "CServerPoolWrapTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSocketReconnectTask",
      valuetype = "CSocketReconnectTask",
    },
    doRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CSocketReconnectRetTask = {
  type = "class",
  inherits = "CServerPoolTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSocketReconnectRetTask",
      valuetype = "CSocketReconnectRetTask",
    },
    doRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CServerScriptRetTask = {
  type = "class",
  inherits = "CServerPoolTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CServerScriptRetTask",
      valuetype = "CServerScriptRetTask",
    },
    doRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CServerScriptTask = {
  type = "class",
  inherits = "CServerPoolWrapTask ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CServerScriptTask",
      valuetype = "CServerScriptTask",
    },
    doRun={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    newScriptRetTask={
      type = "method",
      args="(string: functionName)",
      returns = "CServerScriptRetTask*",
      valuetype = "CServerScriptRetTask"
    },
  },
},

CServerTaskPoolWrap = {
  type = "class",
  inherits = "CSimpleThreadLoopWrap ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CServerTaskPoolWrap",
      valuetype = "CServerTaskPoolWrap",
    },
    newScriptTask={
      type = "method",
      args="()",
      returns = "CServerScriptTask*",
      valuetype = "CServerScriptTask"
    },
  },
},

CServerTaskConfig = {
  type = "class",
  inherits = "IModuleConfig ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CServerTaskConfig",
      valuetype = "CServerTaskConfig",
    },
    getScriptFileName={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    getPoolNum={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
  },
},

CServerTaskPoolMgr = {
  type = "class",
  inherits = "CModuleBase ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CServerTaskPoolMgr",
      valuetype = "CServerTaskPoolMgr",
    },
    newScriptTask={
      type = "method",
      args="(string: scriptName)",
      returns = "CServerScriptTask*",
      valuetype = "CServerScriptTask"
    },
    getLeastPoolWrap={
      type = "method",
      args="()",
      returns = "CServerTaskPoolWrap*",
      valuetype = "CServerTaskPoolWrap"
    },
  },
},

CNetModuleConfig = {
  type = "class",
  inherits = "IModuleConfig ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CNetModuleConfig",
      valuetype = "CNetModuleConfig",
    },
    getPackTempReadBuffLen={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getPackBuffLen={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getPacketNumPerFrame={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
  },
},

CNetModule = {
  type = "class",
  inherits = "CModuleBase ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CNetModule",
      valuetype = "CNetModule",
    },
    addListener={
      type = "method",
      args="(CSocketListener*: listener)",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    getLeastNetLoop={
      type = "method",
      args="()",
      returns = "CNetLoopWrap*",
      valuetype = "CNetLoopWrap"
    },
    addConnector={
      type = "method",
      args="(CSocketConnector*: connector)",
      returns = "bool",
      valuetype = "bool"
    },
    getConfig={
      type = "method",
      args="()",
      returns = "CNetModuleConfig*",
      valuetype = "CNetModuleConfig"
    },
    getSocketHandler={
      type = "method",
      args="(unsigned long long: index)",
      returns = "CSocketHandler*",
      valuetype = "CSocketHandler"
    },
    closeSocket={
      type = "method",
      args="(unsigned long long: index,int: waitSecs)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CSocketServerListener = {
  type = "class",
  inherits = "CSocketListener ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSocketServerListener",
      valuetype = "CSocketServerListener",
    },
    accept={
      type = "method",
      args="(int: inputStreamLen,int: outputStreamLen,int: maxInputStreamLen,int: maxOutputStreamLen)",
      returns = "CSocket*",
      valuetype = "CSocket"
    },
  },
},

CServiceTask = {
  type = "class",
  inherits = "IRunnable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CServiceTask",
      valuetype = "CServiceTask",
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setExcuteNumPerFrame={
      type = "method",
      args="(int: num)",
      returns = "void",
      valuetype = "void"
    },
    getType={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    getExcuteNumPerFrame={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    isUnlimited={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
  },
},

CServiceTaskQue = {
  type = "class",
  inherits = "IAllocatable ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CServiceTaskQue",
      valuetype = "CServiceTaskQue",
    },
    pushTask={
      type = "method",
      args="(CServiceTask*: task)",
      returns = "bool",
      valuetype = "bool"
    },
    update={
      type = "method",
      args="(int: diff)",
      returns = "void",
      valuetype = "void"
    },
    setExecuteNumPerFrame={
      type = "method",
      args="(int: num)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CGxServiceConfig = {
  type = "class",
  inherits = "IModuleConfig ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CGxServiceConfig",
      valuetype = "CGxServiceConfig",
    },
  },
},

CSerivceScriptObject = {
  type = "class",
  inherits = "IScriptObject ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSerivceScriptObject",
      valuetype = "CSerivceScriptObject",
    },
  },
},

GxService = {
  type = "class",
  inherits = "IServiceModule ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "GxService",
      valuetype = "GxService",
    },
    load={
      type = "method",
      args="(string: serverName)",
      returns = "bool",
      valuetype = "bool"
    },
    getNetMgr={
      type = "method",
      args="()",
      returns = "CNetModule*",
      valuetype = "CNetModule"
    },
    addLoad={
      type = "method",
      args="(string: configBuff)",
      returns = "bool",
      valuetype = "bool"
    },
    doScriptEvent={
      type = "method",
      args="(char*: functionName)",
      returns = "void",
      valuetype = "void"
    },
    getNetBroadcast={
      type = "method",
      args="()",
      returns = "CNetBroadcastModule*",
      valuetype = "CNetBroadcastModule"
    },
    getDbMgr={
      type = "method",
      args="()",
      returns = "CDatabaseConnMgr*",
      valuetype = "CDatabaseConnMgr"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    addConnector={
      type = "method",
      args="(CSocketConnector*: pConnector)",
      returns = "bool",
      valuetype = "bool"
    },
    openClientListener={
      type = "method",
      args="(char*: hosts,unsigned short: port,int: tag)",
      returns = "bool",
      valuetype = "bool"
    },
    getServerTaskMgr={
      type = "method",
      args="()",
      returns = "CServerTaskPoolMgr*",
      valuetype = "CServerTaskPoolMgr"
    },
    setScriptEngine={
      type = "method",
      args="(CLuaVM*: scriptEngine)",
      returns = "void",
      valuetype = "void"
    },
    setOption={
      type = "method",
      args="(unsigned int: cfgOpt,unsigned int: val)",
      returns = "void",
      valuetype = "void"
    },
    openServerListener={
      type = "method",
      args="(char*: hosts,unsigned short: port,int: tag)",
      returns = "bool",
      valuetype = "bool"
    },
    openClientConnector={
      type = "method",
      args="(char*: hosts,unsigned short: port,unsigned int: diff,int: tag,bool: blockFlag)",
      returns = "bool",
      valuetype = "bool"
    },
    start={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    init={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    test={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    closeSocket={
      type = "method",
      args="(unsigned long long: index,int: waitSecs)",
      returns = "void",
      valuetype = "void"
    },
    setMainScriptName={
      type = "method",
      args="(string: scriptName)",
      returns = "void",
      valuetype = "void"
    },
    getScriptObject={
      type = "method",
      args="()",
      returns = "CSerivceScriptObject*",
      valuetype = "CSerivceScriptObject"
    },
    addReconnector={
      type = "method",
      args="(CSocketConnector*: pConnector)",
      returns = "bool",
      valuetype = "bool"
    },
    getModuleName={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    getServiceName={
      type = "method",
      args="()",
      returns = "string",
      valuetype = "string"
    },
    setNewServiceFunctionName={
      type = "method",
      args="(string: scriptFuncName)",
      returns = "void",
      valuetype = "void"
    },
    addLogger={
      type = "method",
      args="(IDisplayer*: displayer)",
      returns = "void",
      valuetype = "void"
    },
    doServerEvent={
      type = "method",
      args="(char*: functionName)",
      returns = "void",
      valuetype = "void"
    },
    setSystemEnvironment={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getTaskQue={
      type = "method",
      args="()",
      returns = "CServiceTaskQue*",
      valuetype = "CServiceTaskQue"
    },
    getScriptEngine={
      type = "method",
      args="()",
      returns = "CLuaVM*",
      valuetype = "CLuaVM"
    },
    getServiceConfig={
      type = "method",
      args="()",
      returns = "CGxServiceConfig*",
      valuetype = "CGxServiceConfig"
    },
    getConfigMap={
      type = "method",
      args="()",
      returns = "CConfigMap*",
      valuetype = "CConfigMap"
    },
    addTimer={
      type = "method",
      args="(CIntervalTimer*: timer,bool: isNeedFree)",
      returns = "void",
      valuetype = "void"
    },
    setStopSigno={
      type = "method",
      args="(int: signo)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CMiniServer = {
  type = "class",
  inherits = "GxService ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CMiniServer",
      valuetype = "CMiniServer",
    },
    onAfterLoad={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    onSystemEnvironment={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    onAfterInit={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    TT={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

ManCore = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "ManCore",
      valuetype = "ManCore",
    },
    errorLog={
      type = "method",
      args="(string: msg)",
      returns = "void",
      valuetype = "void"
    },
    infoLog={
      type = "method",
      args="(string: msg)",
      returns = "void",
      valuetype = "void"
    },
    warnLog={
      type = "method",
      args="(string: msg)",
      returns = "void",
      valuetype = "void"
    },
    debugLog={
      type = "method",
      args="(string: msg)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CSocketServerConnector = {
  type = "class",
  inherits = "CSocketConnector ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CSocketServerConnector",
      valuetype = "CSocketServerConnector",
    },
  },
},

CUnsensitiveSStringLessPred = {
  type = "class",
  inherits = "less<GXMISC::CSString> ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CUnsensitiveSStringLessPred",
      valuetype = "CUnsensitiveSStringLessPred",
    },
  },
},

CUnsensitiveStrLessPred = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CUnsensitiveStrLessPred",
      valuetype = "CUnsensitiveStrLessPred",
    },
  },
},

FiledVar = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "FiledVar",
      valuetype = "FiledVar",
    },
  },
},

ITimer = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "ITimer",
      valuetype = "ITimer",
    },
    invalidFunc={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    beginTriggerFunc={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    endTriggerFunc={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
  },
},

CTimerBase = {
  type = "class",
  inherits = "ITimer ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CTimerBase",
      valuetype = "CTimerBase",
    },
    getLastStartTime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    registeInvalidFunc={
      type = "method",
      args="(string: func)",
      returns = "void",
      valuetype = "void"
    },
    isStop={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getEndTime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    cleanUp={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setEndTime={
      type = "method",
      args="(unsigned int: val)",
      returns = "void",
      valuetype = "void"
    },
    setTimerType={
      type = "method",
      args="(ETimerType: val)",
      returns = "void",
      valuetype = "void"
    },
    isInInterval={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getStartTime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    getCallTimes={
      type = "method",
      args="()",
      returns = "int",
      valuetype = "int"
    },
    pause={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    isRun={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    resume={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    getTimerID={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    registeEndFunc={
      type = "method",
      args="(string: func)",
      returns = "void",
      valuetype = "void"
    },
    setStatus={
      type = "method",
      args="(ETimerStatus: val)",
      returns = "void",
      valuetype = "void"
    },
    initInterval={
      type = "method",
      args="(int: interval,int: seconds,int: mins,int: hour,int: day,int: month,int: year)",
      returns = "void",
      valuetype = "void"
    },
    registeAll={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    registeBeginFunc={
      type = "method",
      args="(string: func)",
      returns = "void",
      valuetype = "void"
    },
    isNeedSave={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    onInvalid={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    run={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    setTimerID={
      type = "method",
      args="(unsigned int: val)",
      returns = "void",
      valuetype = "void"
    },
    getNextStartSeconds={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    initTime={
      type = "method",
      args="(unsigned int: startTime,unsigned int: endTime,int: callTimes)",
      returns = "void",
      valuetype = "void"
    },
    stop={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    update={
      type = "method",
      args="(int: diff)",
      returns = "void",
      valuetype = "void"
    },
    getCreateTime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    isPause={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getLastActiveTime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    needStart={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getStatus={
      type = "method",
      args="()",
      returns = "ETimerStatus",
      valuetype = "ETimerStatus"
    },
    isInvalid={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getTimerType={
      type = "method",
      args="()",
      returns = "ETimerType",
      valuetype = "ETimerType"
    },
    isInTimer={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    setStartTime={
      type = "method",
      args="(unsigned int: val)",
      returns = "void",
      valuetype = "void"
    },
    setCallTimes={
      type = "method",
      args="(int: val)",
      returns = "void",
      valuetype = "void"
    },
    setLastActiveTime={
      type = "method",
      args="(unsigned int: val)",
      returns = "void",
      valuetype = "void"
    },
    setCreateTime={
      type = "method",
      args="(unsigned int: val)",
      returns = "void",
      valuetype = "void"
    },
    callScriptFunc={
      type = "method",
      args="(string: func)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CTimerAT = {
  type = "class",
  inherits = "CTimerBase ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CTimerAT",
      valuetype = "CTimerAT",
    },
    setTimeType={
      type = "method",
      args="(EATimeType: val)",
      returns = "void",
      valuetype = "void"
    },
    update={
      type = "method",
      args="(int: diff)",
      returns = "void",
      valuetype = "void"
    },
    defaultInInterval={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getTimeType={
      type = "method",
      args="()",
      returns = "EATimeType",
      valuetype = "EATimeType"
    },
    isInInterval={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
  },
},

CTimerATD = {
  type = "class",
  inherits = "CTimerAT ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CTimerATD",
      valuetype = "CTimerATD",
    },
    getLastStartTime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},

CTimerATW = {
  type = "class",
  inherits = "CTimerAT ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CTimerATW",
      valuetype = "CTimerATW",
    },
    needStart={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getLastStartTime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},

CTimerATM = {
  type = "class",
  inherits = "CTimerAT ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CTimerATM",
      valuetype = "CTimerATM",
    },
    needStart={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getLastStartTime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},

CTimerIT = {
  type = "class",
  inherits = "CTimerBase ",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CTimerIT",
      valuetype = "CTimerIT",
    },
    needStart={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    isInInterval={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
  },
},

CTimerManager = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CTimerManager",
      valuetype = "CTimerManager",
    },
    saveTimer={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    removeTimer={
      type = "method",
      args="(unsigned int: timerID)",
      returns = "void",
      valuetype = "void"
    },
    update={
      type = "method",
      args="(int: diff)",
      returns = "void",
      valuetype = "void"
    },
    isTimerExist={
      type = "method",
      args="(unsigned int: timerID)",
      returns = "bool",
      valuetype = "bool"
    },
    registeIT={
      type = "method",
      args="(unsigned int: startTime,unsigned int: endTime)",
      returns = "CTimerBase*",
      valuetype = "CTimerBase"
    },
    loadTimer={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    getTimer={
      type = "method",
      args="(unsigned int: timerID)",
      returns = "CTimerBase*",
      valuetype = "CTimerBase"
    },
    genTimerID={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
    registe={
      type = "method",
      args="(CTimerBase*: baseTimer,bool: needFree)",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},

CGameTimerInterface = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CGameTimerInterface",
      valuetype = "CGameTimerInterface",
    },
    isNeedBegin={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    getIsNeedBegin={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    setIsNeedBegin={
      type = "method",
      args="(bool: val)",
      returns = "void",
      valuetype = "void"
    },
    setLastActiveTime={
      type = "method",
      args="(unsigned int: val)",
      returns = "void",
      valuetype = "void"
    },
    getLastActiveTime={
      type = "method",
      args="()",
      returns = "unsigned int",
      valuetype = "unsigned int"
    },
  },
},

CGameTimerBase = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CGameTimerBase",
      valuetype = "CGameTimerBase",
    },
    isInvalid={
      type = "method",
      args="()",
      returns = "bool",
      valuetype = "bool"
    },
    update={
      type = "method",
      args="(unsigned int: diff)",
      returns = "void",
      valuetype = "void"
    },
  },
},

CGamePassTimerBase = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CGamePassTimerBase",
      valuetype = "CGamePassTimerBase",
    },
    updateTimer={
      type = "method",
      args="(unsigned int: diff)",
      returns = "void",
      valuetype = "void"
    },
    onPassWeekday={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    onPassDay={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    onPassMonth={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
    initTimer={
      type = "method",
      args="(unsigned int: lastTime)",
      returns = "bool",
      valuetype = "bool"
    },
    onPassHour={
      type = "method",
      args="()",
      returns = "void",
      valuetype = "void"
    },
  },
},

CUCStringHashMapTraits = {
  type = "class",
  childs = {
    new = {
      description = "new object",
      type = "function",
      args = "()",
      returns = "CUCStringHashMapTraits",
      valuetype = "CUCStringHashMapTraits",
    },
  },
},

}
end