cppapi = {} 
cppapi.rootpath = "E:/work/project/code/trunk/shenglqs/server/trunk/server/"; 
