./zbstudio.sh -cfg t/test.lua -cfg "ini='t/test.ini'"
